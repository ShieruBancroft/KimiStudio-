# Bitácora · AutoStudio 360

## 2026-11-08 · Cubo armado y orientación vertical de la cámara

El usuario terminó de armar el cubo. Algunas figuras son muy altas y no caben con la cámara horizontal, así que gira el trípode 90° para dejar la cámara vertical. La Pi estaba en `192.168.1.7` (PC por cable) con la red `AutoStudio360` activa.

**Decisiones**
- Orientación en el menú Cámara con solo dos botones, **Horizontal** y **Vertical**. El usuario siempre gira el trípode hacia el mismo lado; se descartó tener Derecha e Izquierda.
- La Pi no detecta cómo está la cámara: al girar el trípode hay que tocar el botón. El ajuste se guarda en `~/autostudio/ajustes.json` y sobrevive a los reinicios.
- Vertical = imagen completa 9:16. Se probó recortar a 4:5 (2/3 del corte arriba, para no ver el techo de la caja) y el usuario pidió volver al 9:16 porque la imagen quedaba chica. También se descartó convertir a 16:9 con bandas a los lados.
- En vertical se oculta el formato "4K vertical" de la cámara (es un recorte del sensor y con el trípode girado saldría acostado).

**Hecho**
- `pi/camara.py`: `set_giro()`. En vertical, la vista previa y las fotos se giran con `transpose=1` (la foto 4K tarda ~3,6 s en vez de ~3 s). El video no se recodifica: lleva la marca de giro con `-display_rotation:v:0 -90` (ffmpeg 7.1 en la Pi). Las flechas del PTZ se reasignan para que sigan la pantalla (web y bot). `version_liviana` escala sin deformar los videos verticales.
- `pi/web.py`: `POST /api/giro`; `/api/estado` incluye `giro`. `index.html`: botones Horizontal/Vertical y vista previa en 9:16.
- Probado con la cámara real: foto 4K 2160×3840, 1080p 1080×1920, video 1080×1920 derecho en Edge, copia para Telegram 720×1280 (10 s para 4 s de video), miniaturas correctas. Desplegado (commits `e7fb0e8`, `d891744`, `ce1ec85`).
- WiFi `AutoStudio360`: la clave sigue siendo `12345678`. Windows pedía un "PIN" (WPS) y lo daba por incorrecto. Este PC quedó conectado con un perfil guardado por `netsh wlan add profile`.

**A medias / pendiente inmediato**
- El usuario debe confirmar que, en vertical, cada flecha de la cámara mueve la imagen hacia donde apunta.
- Video vertical por Telegram sin probar (el bot manda el original si pesa menos de 48 MB; el giro va como marca en el MP4).

**Sigue**
- Probar los modos de video con la base en la cabina armada (Vuelta 360 de frente, bucle, Cancelar).
- Sensor Hall (paso 34) y `HOME`; asegurar el conector del motor; pruebas de carga 1–3 kg.

## 2026-10-30 · Base giratoria funcionando, video coordinado con la base e informes

La Pi estaba en `192.168.1.7`. El usuario armó la Parte 8 de la guía hasta el paso 33 (TMC2208 + motor) e hizo la revisión del paso 35; el sensor Hall (paso 34) no está puesto. Motor montado en la base con el plato pequeño directo en el eje.

**Decisiones**
- Video con la base desde el menú Cámara: fila "Base durante el video" con Quieta / Vuelta 360 / Paradas / Vaivén (se recuerda en el navegador). Vuelta 360 a velocidad constante (arranca antes del primer cuadro, frena después: video en bucle). Paradas: 4 × 90° a 60 °/s, 120 °/s². Vaivén: 0 → +45 → −45 → 0. Todos empiezan y terminan en 0°.
- Con 5 s, Vuelta y Paradas no se permiten (límite de 60 °/s del firmware); el firmware no se tocó.
- Botón Cancelar sobre la vista: corta ffmpeg, borra el video a medias, frena la base y vuelve a 0°.
- Escenas de luz: fila de 4 botones alineados con su temperatura (antes eran puntos sobre la barra de tono, alternados arriba/abajo).
- Fotos 360 (24 fotos cada 15° + visor) queda como idea para después; la Pi 3 B+ alcanza, no hace falta un computador.
- Las pruebas de los modos de video con la cámara se hacen cuando la base esté armada en la cabina.

**Hecho**
- Pruebas de la base por serial desde el PC (registro en el informe): 90° ida y vuelta, `TURN 12`, `SPIN`/`STOP`, `GOTO 0`, vuelta con ~450 g y 3 × `TURN 8` con carga: siempre en la marca, sin calentamiento. Vref 1,12 V.
- Falla "zumba y no gira": contacto flojo del conector del motor en la protoboard (ver BUGS.md).
- Menú Base de la web probado con el ESP32 en la Pi: todo funcionó (19 `POST /api/base`, todos 200).
- `pi/rodaje.py` nuevo; `camara.grabar` con `-progress` (detecta el primer cuadro, mide `retardo`) y `cancelar_video`; `/api/grabar` con `base`, `/api/grabar/cancelar`; `/api/estado` con `esp32`, `video_base`, `fase`, `base_ocupada`; el bot avisa si cancelan su video. Desplegado; respaldo `~/respaldo-autostudio-20261030.tgz`.
- Informe de pruebas (https://claude.ai/artifact/4K37d4huDJAfCyYkyYMcqD) y documento de evolución del proyecto (https://claude.ai/artifact/SyJbJ4Jnsmzvdor1TX1n1d), pedidos por el docente.

**A medias / pendiente inmediato**
- Probar los 4 modos de video y Cancelar con la cámara y la base armada; revisar que la Vuelta 360 empiece de frente.
- Push a GitHub (siguen commits sin subir).

**Sigue**
- Sensor Hall (paso 34) y `HOME`; asegurar el conector del motor; pruebas de carga 1–3 kg.
- Montaje en la cabina y validación con productos.

## 2026-10-25 · Firmware en el ESP32, 4 torres de luz probadas y menús Base / Luces en la web

La Pi estaba en el router `192.168.1.x` (IP `192.168.1.7`). El usuario corrigió la guía de armado desde el paso 8 (la protoboard no coincidía con el TMC2208): `AutoStudio_360_Armado_paso_a_paso.html` + `.md` reemplazan a `AutoStudio360_Guia_Armado.html` para el cableado.

**Decisiones**
- El firmware v2.0 no cambia con la guía nueva: los pines del ESP32 son los mismos y MS1/MS2 a 3,3 V = 16 micropasos.
- Página: 3 botones con icono (Cámara, Base, Luces) y un menú abierto a la vez; se recuerda el último en el navegador.
- Escenas de luz (puntos sobre la barra de tono, fijan adelante y atrás): Cálido 90 %/3200 K + 60 %/3200 K; Contraluz 85 %/4300 K + 100 %/6500 K; Producto 100 %/5000 K + 70 %/5000 K; Luz día 100 %/5600 K + 85 %/5600 K.
- Luces y base solo en la web por ahora; el bot queda igual.

**Hecho**
- `arduino-cli` instalado (winget `ArduinoSA.CLI`), núcleo esp32 y FastAccelStepper 2.0.1. Firmware compilado (372 KB) y subido por COM3. La placa no entra sola en modo de carga: mantener BOOT durante "Connecting…" y presionar EN al terminar.
- Pruebas de luces desde el PC: T1 sola, luego las 4 torres: zonas separadas, frío/cálido de cada zona, rampas de tono y brillo.
- `pi/esp32.py`: serial con reconexión automática; `/api/esp32`, `/api/luces`, `/api/base` en `web.py`; menús Base y Luces en `index.html`. `python3-serial` instalado en la Pi. Probado con el ESP32 en la Pi.
- Arreglo de la cámara que bajaba en el primer toque tras prender la Pi (ver BUGS.md).
- Respaldo de la versión anterior en la Pi: `~/respaldo-autostudio-20261025.tgz`.

**A medias / pendiente inmediato**
- Menú Base sin probar con driver y motor.
- Push a GitHub (siguen commits sin subir; pide credenciales).

**Sigue**
- Parte 8 de la guía nueva sin motor (pasos 25–31: TMC2208, jumpers, condensador, 12 V, Vref). Pasos 32–34 cuando el motor esté a mano.
- Revisar las escenas de luz en la cámara y ajustar.

## 2026-10-11 · Página de la Pi reparada, botón Apagar y clave del WiFi propio

La Pi estaba en otro router (por cable, `192.168.1.7`, se encuentra por `shieru-i.local`).

**Decisiones**
- Apagar la Pi desde la web, sin comandos: botón "Apagar" en la cabecera, junto a "Presentación".
- Clave de la red `AutoStudio360`: `12345678` (de prueba; el usuario pidió `1234@` pero WPA2 exige 8+ caracteres).

**Hecho**
- Diagnóstico de "se queda en conectando": `index.html` y `camara.py` de la Pi estaban dañados (ver BUGS.md). Se desplegó todo `pi/` del repo; los md5 coinciden.
- `POST /api/apagar` en `pi/web.py` (rechaza si hay captura en curso; `sudo systemctl poweroff` a los 2 s). La página confirma, espera a que la Pi deje de responder, 15 s más, y dice "Listo, ya puedes desconectar".
- Llave SSH de este PC copiada a la Pi.

**A medias / pendiente inmediato**
- Bajo voltaje constante con la fuente original: revisar fuente y cable micro-USB.
- Probar el botón Apagar de verdad (requiere reconectar la fuente después).
- Push: `d40034a` y este commit siguen sin subir (GitHub pide credenciales).

**Sigue**
- Lo mismo del 2 oct: compilar firmware, `pi/esp32.py`, armado de la zona 1.

## 2026-10-02 (tarde) · Guía de armado completa y firmware único del ESP32

Sesión en un PC nuevo (sin git, node ni Playwright al empezar; se instalaron git y node con winget).

**Decisiones**
- Una sola guía de armado (`AutoStudio360_Guia_Armado.html`) reemplaza, para el cableado, a las dos guías PDF de septiembre. La impresión 3D y el modelo de la base siguen siendo los del PDF de base.
- Zonas de luz: zona 1 = adelante (T1+T2) en D18 frío / D19 cálido; zona 2 = atrás (T3+T4) en D23 / D32. Motor en D25 EN / D26 STEP / D27 DIR; Hall opcional en D33.
- El + de cada cinta va directo a la barra +12V (no al OUT+ del módulo). Los dos cables azules de una zona entran juntos en el OUT− del módulo frío; igual los amarillos en el cálido.
- Los esquemas "con todo junto" no se entienden: el usuario pidió algo paso a paso. La guía ahora muestra, por paso, solo dos piezas y un cable (29 pasos de luces, 21 de base), con casilla "Listo" y lista completa. Los esquemas generales quedaron solo como mapa de referencia (bornera, módulo, TMC2208, tabla de electrónica).
- Mapa de barras fijo: roja = fuente, VIN+ de los 4 módulos (2–5), + de las 4 cintas (6–9), VM del driver (10); negra = fuente, VIN− (2–5), GND del ESP32 (6), GND de potencia del driver (7).

**Hecho**
- `esp32/AutoStudio360/AutoStudio360.ino`: firmware único v2.0 (fusión de Luces4Torres y BaseGiratoria de los PDF). `LIGHT <zona 0|1|2> <brillo> [K] [ms]`, `TEST` por zona, comandos de base sin cambios, `STATUS` con ángulo y zonas. **No compilado aún** (no hay Arduino IDE en este PC).
- Guía HTML publicada como artefacto (https://claude.ai/artifact/MVfud1bhksFdM2pHZLi9zp, privada): inventario, seguridad, mapa de pines, barras, módulos, cinta, torres, base, Vref, revisión con multímetro, orden de primer encendido, comandos, prueba desde la Pi con pyserial, problemas y soluciones, firmware en anexo.
- Verificación: `node --check` del script, prueba automática de que los 46 pasos apuntan a pines existentes, capturas con Edge headless (`msedge --headless=new --screenshot`).

**A medias / pendiente inmediato**
- Compilar el firmware en el Arduino IDE (placa ESP32 Dev Module, núcleo 3.1+, librería FastAccelStepper) y subirlo al ESP32: etapa 1 del primer encendido.
- Push del repo desde este PC (necesita credenciales de GitHub).
- Lo del 26 sep sigue abierto: reconectar la Link 2, seguridad de la Pi y del bot, prueba del portal en celular.

**Sigue**
- Módulo en la Pi (`pi/esp32.py`) que hable con el firmware por `/dev/ttyUSB0` y botones de luces/giro en la web y el bot.
- Comprar lo de ferretería y armar la zona 1 con la torre T1 siguiendo los pasos 1–13 de la guía.

## 2026-10-02 · Llegaron las piezas de luces y control

**Qué llegó** (fotos en `llego/`, enlaces y tabla en ROADMAP.md, "Inventario recibido")
- 10 módulos MOS XY-MOS con chips D4184 (confirmado en la foto del vendedor). Se usan 4; 6 de repuesto.
- ESP32 de 30 pines con USB-C y chip CH340C, pines ya soldados, más la placa de bornera MRD068A. Los rótulos coinciden pin a pin con el ESP32.
- Cinta COB CCT 12 V de 5 m, 10 mm de ancho, 11,52 W/m, con los 3 cables soldados solo en un extremo.

**Decisiones**
- Se mantiene el plan de 2 zonas con 4 módulos. Con la placa de bornera, el tramo ESP32 → módulos se hace con cable 22 AWG pelado, no con jumpers dupont.
- El cable de señal se suelda directo en el hueco TRIG/PWM de cada módulo; no se compran tiras de pines.
- Consumo real de luces: ~16 W / 1,4 A con las 4 torres a tope. La fuente de 12 V / 5 A queda holgada; una de 3 A también sirve.

**Pendiente de comprar** (sin cambios de fondo respecto a la lista del roadmap)
- Adaptador 12 V con jack de bornera, 2 barras o Wago 221, 4 perfiles de aluminio de 35 cm, cable 22 AWG (4 colores) y 18 AWG, termoencogible, condensador 100 µF, rodamientos y tornillos de la base.
- Cable USB-A a USB-C de datos para el ESP32.
- Cautín, estaño y multímetro si no los tienen.

**Sigue**
- Lo del 26 sep sigue abierto: reconectar la Link 2, seguridad de la Pi y del bot, prueba del portal en celular.
- Firmware único del ESP32 y prueba por USB desde la Pi, antes de cablear 12 V.

## 2026-09-26 · Raspberry Pi funcionando + web, bot y red propia

**Decisiones**
- Raspberry Pi 3 B+ (no 3 B): soporta WiFi 5 GHz. Pi OS Lite 64 bits en Kingston 16 GB. La microSD "125 GB" de AliExpress es falsa (~4 GB reales según ValiDrive): no usarla.
- Usuario `shieru`, hostname `Shieru-i`, acceso SSH por llave desde el PC, sudo sin clave.
- Un solo programa dueño de la Link 2 (`pi/camara.py`): vista previa 720p recomprimida a 480p (~11 KB/cuadro), fotos 4K (horizontal 3840×2160, vertical 2176×3840 o 1080p), video 1080p H.264 copiado sin recodificar.
- PTZ por ioctl directo (12 ms por comando en vez de ~150 ms con `v4l2-ctl`).
- Red: WiFi de casa como principal; si no hay red conocida, la Pi crea `AutoStudio360` (5 GHz, canal 36, 10.42.0.1). Toggle "Presentación" en la web la fija aunque haya WiFi. Portal cautivo con bienvenida y botón "Copiar dirección".
- La dirección para Chrome queda en números: `http://10.42.0.1`. Se descartó un nombre (`autostudio.lan` no resuelve con datos móviles activos; un dominio público no está disponible).
- Web sin emojis (preferencia del usuario). El bot de Telegram sí conserva emojis por ahora.

**Hecho** (ROADMAP semana 8, 9, 10, 11 y Opción Pro)
- Pi instalada y en red; Link 2 validada (foto, video, PTZ).
- Servicio `pi/`: web con vista previa, flechas continuas, zoom, 5 posiciones (cargadas desde `presets.json`), galería con miniaturas, aviso "Tomando foto".
- Bot @Photostudioshieru_bot privado: foto, foto vertical, video (convierte a 720p si pasa de 48 MB), encuadre con flechas, posiciones, estado.
- systemd: `autostudio.service` (puertos 80 y 8000) y `red-respaldo.timer`.

**Tarde (hardware)**
- Carcasa acrílica con ventilador 5 V en pines 4 (rojo) y 6 (negro): de 66–68 °C a ~35 °C.
- La fuente anterior daba voltaje bajo (`throttled=0x50005`); con la fuente nueva `0x0`.
- El servicio ya no se cae si la cámara no está: web y portal siguen, y la cámara se reconecta sola.

**A medias / pendiente inmediato**
- Reconectar la Link 2 a la Pi (quedó desconectada tras montar la carcasa) y confirmar que aparece.
- Seguridad antes de la sustentación: cambiar la contraseña de la Pi (cloud-init la devolvió a la del Imager), SSH solo por llave, `/revoke` del token del bot (se pegó en el chat), clave más fuerte para `AutoStudio360`.
- Probar en celular real el portal nuevo con "Copiar dirección" y la descarga desde Chrome.

**Sigue**
- Firmware del ESP32 (motor + luces) y su control desde la Pi.
- Fijar exposición, balance de blancos y foco durante la captura.
- Hotspots de celulares como redes conocidas (para Telegram fuera de casa) o adaptador WiFi USB.
