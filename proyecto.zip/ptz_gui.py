"""Interfaz de prueba para la Insta360 Link 2.

Teclado: flechas / WASD = pan-tilt · Q/E = zoom · H = home · 1-6 = ir a preset · Shift+1-6 = guardar preset
"""
import json
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk

import cv2
from PIL import Image, ImageTk

from ptz import PTZCamera

PRESETS_FILE = Path(__file__).with_name("presets.json")
STEP = {"Pan": 5, "Tilt": 5, "Zoom": 20}
PREVIEW_W = 640


class App:
    def __init__(self, root):
        self.root = root
        self.cam = PTZCamera()
        root.title(f"PTZ · {self.cam.name}")
        root.configure(padx=12, pady=12)

        self.presets = json.loads(PRESETS_FILE.read_text()) if PRESETS_FILE.exists() else {}
        self.vars = {}

        # --- Vista previa ---
        self.preview = ttk.Label(root, text="Vista previa apagada", anchor="center", width=60)
        self.preview.grid(row=0, column=0, rowspan=3, sticky="nsew", padx=(0, 12))
        self.cap = None
        self.frame_img = None

        # --- Sliders ---
        sliders = ttk.LabelFrame(root, text="Posición", padding=8)
        sliders.grid(row=0, column=1, sticky="new")
        current = self.cam.get_all()
        for r, axis in enumerate(("Pan", "Tilt", "Zoom", "Roll")):
            if axis not in self.cam.ranges:
                continue
            lo, hi, _ = self.cam.ranges[axis]
            var = tk.IntVar(value=current.get(axis) or 0)
            self.vars[axis] = var
            ttk.Label(sliders, text=axis, width=5).grid(row=r, column=0)
            tk.Scale(sliders, from_=lo, to=hi, orient="horizontal", length=260, variable=var,
                     command=lambda v, a=axis: self.cam.set(a, float(v))).grid(row=r, column=1)

        # --- Pad direccional ---
        pad = ttk.LabelFrame(root, text="Mover", padding=8)
        pad.grid(row=1, column=1, sticky="new", pady=8)
        btn = lambda t, cmd, r, c: ttk.Button(pad, text=t, width=5, command=cmd).grid(row=r, column=c, padx=2, pady=2)
        btn("▲", lambda: self.nudge("Tilt", +1), 0, 1)
        btn("◀", lambda: self.nudge("Pan", -1), 1, 0)
        btn("⌂", self.home, 1, 1)
        btn("▶", lambda: self.nudge("Pan", +1), 1, 2)
        btn("▼", lambda: self.nudge("Tilt", -1), 2, 1)
        btn("Z+", lambda: self.nudge("Zoom", +1), 0, 3)
        btn("Z−", lambda: self.nudge("Zoom", -1), 2, 3)

        # --- Presets ---
        pr = ttk.LabelFrame(root, text="Presets (clic = ir · clic derecho = guardar)", padding=8)
        pr.grid(row=2, column=1, sticky="new")
        self.preset_btns = {}
        for i in range(1, 7):
            b = ttk.Button(pr, width=6, command=lambda k=str(i): self.recall(k))
            b.bind("<Button-3>", lambda e, k=str(i): self.store(k))
            b.grid(row=(i - 1) // 3, column=(i - 1) % 3, padx=2, pady=2)
            self.preset_btns[str(i)] = b
        self.refresh_preset_labels()

        # --- Barra inferior ---
        bottom = ttk.Frame(root)
        bottom.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        self.preview_on = tk.BooleanVar(value=False)
        ttk.Checkbutton(bottom, text="Vista previa", variable=self.preview_on,
                        command=self.toggle_preview).pack(side="left")
        self.status = ttk.Label(bottom, text="")
        self.status.pack(side="right")

        # --- Teclado ---
        keys = {"Left": ("Pan", -1), "a": ("Pan", -1), "Right": ("Pan", 1), "d": ("Pan", 1),
                "Up": ("Tilt", 1), "w": ("Tilt", 1), "Down": ("Tilt", -1), "s": ("Tilt", -1),
                "e": ("Zoom", 1), "q": ("Zoom", -1)}
        for k, (axis, sign) in keys.items():
            root.bind(f"<{k}>" if len(k) > 1 else k, lambda e, a=axis, s=sign: self.nudge(a, s))
        root.bind("h", lambda e: self.home())
        for i, sym in enumerate("!@#$%&", start=1):  # Shift+número en teclado ES/US
            root.bind(str(i), lambda e, k=str(i): self.recall(k))
            root.bind(sym, lambda e, k=str(i): self.store(k))

        root.protocol("WM_DELETE_WINDOW", self.close)
        self.poll_status()

    # --- Acciones ---
    def nudge(self, axis, sign):
        var = self.vars[axis]
        var.set(self.cam.clamp(axis, var.get() + sign * STEP[axis]))
        self.cam.set(axis, var.get())

    def apply(self, values):
        for axis, v in values.items():
            if axis in self.vars:
                self.vars[axis].set(v)
                self.cam.set(axis, v)

    def home(self):
        self.apply({"Pan": 0, "Tilt": 0, "Zoom": self.cam.ranges["Zoom"][0], "Roll": 0})

    def store(self, key):
        self.presets[key] = {a: v.get() for a, v in self.vars.items()}
        PRESETS_FILE.write_text(json.dumps(self.presets, indent=2))
        self.refresh_preset_labels()
        self.status.config(text=f"Preset {key} guardado")

    def recall(self, key):
        if key in self.presets:
            self.apply(self.presets[key])

    def refresh_preset_labels(self):
        for k, b in self.preset_btns.items():
            b.config(text=f"{k} ●" if k in self.presets else k)

    def poll_status(self):
        # Lee la posición real de la cámara (por si la mueve el tracking o la app oficial)
        def read():
            vals = self.cam.get_all()
            txt = "   ".join(f"{a}: {v}" for a, v in vals.items())
            self.root.after(0, lambda: self.status.config(text=txt))
        threading.Thread(target=read, daemon=True).start()
        self.root.after(500, self.poll_status)

    # --- Video ---
    def toggle_preview(self):
        if self.preview_on.get():
            self.cap = cv2.VideoCapture(self.cam.index, cv2.CAP_DSHOW)
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            self.update_frame()
        else:
            self.stop_preview()

    def update_frame(self):
        if not self.cap:
            return
        ok, frame = self.cap.read()
        if ok:
            h, w = frame.shape[:2]
            frame = cv2.resize(frame, (PREVIEW_W, int(h * PREVIEW_W / w)))
            self.frame_img = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)))
            self.preview.config(image=self.frame_img, text="")
        self.root.after(33, self.update_frame)

    def stop_preview(self):
        if self.cap:
            self.cap.release()
            self.cap = None
        self.preview.config(image="", text="Vista previa apagada")

    def close(self):
        self.stop_preview()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
