---
name: pi-acceso
description: "Cómo entrar y desplegar en la Raspberry Pi de AutoStudio 360 (IPs, rutas, servicios, gotchas)"
metadata:
  node_type: memory
  type: reference
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-11-09T04:25:16.321Z
---

- SSH por llave: `ssh shieru@192.168.50.15` (WiFi de casa) o `shieru@192.168.50.254` (cable). En modo presentación la Pi no está en el WiFi de casa: usar la IP del cable. En otras redes, buscarla por mDNS `shieru-i.local` (el 11 oct 2026 en el router del PC nuevo fue 192.168.1.7). El PC nuevo ya tiene llave en la Pi (id_ed25519, 11 oct 2026). Si el usuario debe teclear una contraseña, que lo haga en una ventana aparte de PowerShell: con `!` el prompt de contraseña se cuelga.
- Si la página se queda en "conectando…" con la imagen viva: comparar md5 de `~/autostudio` contra `pi/` del repo. El 11 oct 2026 la Pi tenía `index.html` y `camara.py` dañados (bajo voltaje + apagados sucios, `vcgencmd get_throttled` = 0x50000).
- sudo sin clave (`/etc/sudoers.d/010_shieru-nopasswd`). Contraseña actual = la del Imager (cloud-init la restauró); el usuario debe cambiarla. No guardar contraseñas en memoria.
- Código en `~/autostudio/` (venv `.venv` con Flask). Media en `~/autostudio-media/` (+ `.miniaturas/`). Secretos en `~/.config/autostudio/secretos.env` (TELEGRAM_TOKEN, ALLOWED_CHATS). Posiciones en `~/autostudio/presets.json`.
- Desplegar: `scp pi/*.py` y `pi/static/*` → `sudo systemctl restart autostudio`. Logs: `journalctl -u autostudio`.
- Red: conexiones NM `Kasproduction corp ` (SSID con espacio final, prioridad 10) y `autostudio-ap` (−10, o 100 en modo presentación; bandera `~/.config/autostudio/modo_presentacion`). DNS del AP en `/etc/NetworkManager/dnsmasq-shared.d/autostudio.conf`. cloud-init desactivado.
- 25 oct 2026 la Pi estaba otra vez en `192.168.1.7` (router del PC, por cable); probar esa IP primero si 192.168.50.x no responde.
- ESP32 por USB: `/dev/ttyUSB0` (CH340). `python3-serial` instalado por apt (25 oct); `shieru` ya está en `dialout`. Ver [[esp32-carga-firmware]].
- Respaldo antes del despliegue del 25 oct: `~/respaldo-autostudio-20261025.tgz`.
- Gotcha PowerShell→ssh: comillas dobles expanden `$()` en el PC; usar comillas simples para el comando remoto.
- Gotchas: `iw` está en `/usr/sbin`; `pkill -f autostudio.py` dentro de un ssh mata la propia sesión; en PowerShell el pipe de contraseñas agrega CRLF (usar Bash `printf`).
- Probar la página: `node --check` del `<script>` y Playwright con `channel="msedge"` (en el PC nuevo no hay Playwright: ver [[pc-nuevo-herramientas]]).

Ver [[autostudio360-proyecto]].

- 8 nov 2026: Pi en `192.168.1.7` (PC por cable). Comandos remotos con comillas anidadas o `$`: escribir un `.sh` en el scratchpad, `scp` a `/tmp` y `bash` (pasarlo por pipe desde PowerShell mete un BOM). Windows pide un "PIN" (WPS) al conectarse a `AutoStudio360`: hay que tocar "Conectarse con una clave de seguridad", o usar `netsh wlan add profile` con un XML WPA2PSK (este PC ya lo tiene guardado). Ajustes de cámara en `~/autostudio/ajustes.json`.
- 30 oct 2026: respaldo antes de desplegar video con base: `~/respaldo-autostudio-20261030.tgz`. Al reiniciar el servicio, `esp32.py` reinicia el ESP32 (el plato pierde el cero).
