---
name: esquemas-paso-a-paso
description: Para el usuario (novato en electrónica) los esquemas con todo junto no sirven; quiere un paso a paso con dos piezas y un cable por paso
metadata:
  node_type: memory
  type: feedback
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-03T00:46:38.942Z
---

Al explicar conexiones, no usar esquemas generales con todas las piezas y cables a la vez. Mostrar un paso por cable: las dos piezas dibujadas como se ven de verdad (tornillos con nombre, huecos, cables de colores), el tornillo exacto marcado, y una frase. Las tablas "cable → destino" como resumen sí le sirven.

**Why:** el 2 oct 2026 dijo "no entendí esos esquemas... no sé cómo va cada cable de la cinta led a los módulos y cómo se conecta eso al esp32, necesito un esquema que diga paso a paso cómo conectar todo". La versión con paso a paso interactivo (29 pasos luces, 21 base) fue la respuesta.
**How to apply:** en la guía de armado el patrón está hecho (script `stepper` en `AutoStudio360_Guia_Armado.html`: piezas = funciones que devuelven SVG + pines; pasos = lista `{a:[pieza,pin], b:[pieza,pin], c:color}`). Reusar ese formato para cualquier conexión nueva. Si un paso no se entiende, redibujar ese paso, no el conjunto. Ver [[guia-armado-decisiones]], [[sin-emojis-en-ui]].
