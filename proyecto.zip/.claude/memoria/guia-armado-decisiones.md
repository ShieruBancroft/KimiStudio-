---
name: guia-armado-decisiones
description: "Decisiones de cableado y pines fijadas en la guía de armado del 2 oct 2026 (zonas, módulos, barras, firmware único)"
metadata:
  node_type: memory
  type: project
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-26T01:38:55.377Z
---

Fijado el 2 oct 2026 en `AutoStudio360_Guia_Armado.html` y `esp32/AutoStudio360/AutoStudio360.ino`:

- Un solo ESP32 (30 pines, placa de bornera MRD068A). Luces en 2 zonas con 4 módulos MOS D4184: zona 1 = adelante (T1+T2) → D18 frío, D19 cálido (módulos Z1-F, Z1-C); zona 2 = atrás (T3+T4) → D23 frío, D32 cálido (Z2-F, Z2-C). Motor: D25 EN, D26 STEP, D27 DIR. Hall opcional D33. 3V3 → VIO, MS1, MS2 del TMC2208 (1/16 paso).
- El + de cada cinta va directo a la barra +12V (no al OUT+ del módulo). Los dos azules de una zona van juntos al OUT− del módulo frío; los dos amarillos al OUT− del cálido. El cable de señal se suelda en el hueco TRIG/PWM del módulo; el hueco GND del módulo queda libre (ya unido a VIN−).
- Mapa de barras (12 bornes): roja = 1 fuente, 2–5 VIN+ de Z1-F/Z1-C/Z2-F/Z2-C, 6–9 + de T1..T4, 10 VM del driver. Negra = 1 fuente, 2–5 VIN−, 6 GND del ESP32, 7 GND de potencia del driver.
- La cinta real trae cables rojo/blanco/amarillo (no azul): cuál es frío se decide con la "prueba de 10 segundos".
- Firmware v2.0: comandos `LIGHT <zona 0|1|2> <brillo> [K] [ms]`, `OFF`, `TEST` (por zona), y los de la base (`ROT GOTO TURN SPIN STOP ESTOP ZERO HOME SPEED ACCEL MOTOR INVERT MREV SETGEAR`), más `STATUS INFO PING`. Respuestas empiezan por OK/DONE/ERR/STATUS/INFO/PONG/READY. Serial 115200.
- Las guías PDF de septiembre quedan solo como referencia (impresión 3D de la base sigue vigente).
- 25 oct 2026: la guía vigente es `AutoStudio_360_Armado_paso_a_paso.html` (36 pasos en 9 partes; el usuario la corrigió desde el paso 8). TMC2208 en protoboard filas c/f, columnas 3–10 (DIR f3, GND c3, EN f10, VM c10); 3V3 → j13; MS1 j9, MS2 j8, VIO b4; EN/STEP/DIR → j10/j4/j3. Pines del ESP32 sin cambios: el firmware no se tocó.

**Why:** evita volver a decidir pines y cableado; el firmware y la guía dependen de esto.
**How to apply:** cualquier cambio de pin se hace en los dos lugares (guía y .ino). Ver [[siguiente-paso]], [[esquemas-paso-a-paso]].
