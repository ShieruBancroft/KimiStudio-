---
name: estado-sin-tiempos
description: "Al reportar estado de piezas/tareas, el usuario quiere solo qué hay, qué falta y qué toca hacer; sin cronogramas ni repetir pendientes menores (p. ej. reconectar la Link 2)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-03T00:47:25.762Z
---

Cuando el usuario pide "estado de partes" o "qué toca hacer", responder con inventario y acciones. No meter fechas, semanas ni "se corre el plan". No repetir pendientes pequeños ya conocidos (reconectar la Link 2 lo considera insignificante).

**Why:** el 2 oct 2026 pidió explícitamente "no tengas en cuenta tiempos, lo que necesito es status de partes y qué toca hacer, y deja de recordar lo de la Link".
**How to apply:** tabla o lista de piezas con estado (llegó / en camino / falta comprar) y lista de tareas en orden. Ver [[autostudio360-proyecto]].
