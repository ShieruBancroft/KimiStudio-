---
name: sin-emojis-en-ui
description: "Interfaces web del usuario: cero emojis; usar texto o íconos SVG"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-03T00:47:14.574Z
---

En las interfaces web (páginas, botones, galerías, guías HTML) no usar emojis: texto claro o íconos SVG en línea.

**Why:** el usuario lo pidió explícitamente y se molestó porque ya lo había dicho antes ("recuerda cero emojis", 26 sep 2026, web de AutoStudio 360).
**How to apply:** revisar cualquier HTML/UI antes de entregarlo (en la guía de armado se chequea con un script que cuenta emojis); el bot de Telegram quedó con emojis en sus botones — preguntar si también los quiere fuera ahí. Ver [[autostudio360-proyecto]].
