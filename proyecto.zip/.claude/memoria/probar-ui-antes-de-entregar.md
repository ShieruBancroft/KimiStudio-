---
name: probar-ui-antes-de-entregar
description: Validar el JS y mirar la página renderizada antes de pedirle al usuario que la pruebe
metadata:
  node_type: memory
  type: feedback
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-03T00:47:19.260Z
---

Antes de decirle al usuario "recarga y prueba", validar el `<script>` con `node --check` y abrir la página en un navegador (Playwright con Edge, o `msedge --headless=new --screenshot` si no hay Playwright) revisando errores JS, el flujo tocado y cómo se ve.

**Why:** el 26 sep 2026 un `\n` generado dentro de un string JS rompió toda la web; el usuario la probó y "no funciona" antes de que se detectara. El 2 oct la captura con Edge mostró rótulos recortados y cables mal ruteados en la guía antes de publicarla.
**How to apply:** en cada cambio de HTML/JS de AutoStudio 360 (y proyectos similares); simular con `route.fulfill` las acciones que cortarían la red o moverían hardware. Ver [[pi-acceso]], [[pc-nuevo-herramientas]].
