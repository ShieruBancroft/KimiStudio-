---
name: controles-alineados
description: "En la web de la cabina, los botones de opciones van alineados en filas parejas, no posicionados según su valor"
metadata:
  node_type: memory
  type: feedback
  originSessionId: cabbdc4c-a759-4f02-a006-399a90593630
  modified: 2026-10-30T20:09:36.600Z
---

El 30 oct 2026 el usuario pidió alinear las escenas de luz, que estaban como puntos sobre la barra de tono, en la posición de su temperatura y alternados arriba y abajo. Se cambiaron por una fila de 4 botones iguales, con el valor debajo del nombre.

**Why:** los botones desalineados se ven desordenados y cuesta tocarlos en el celular.
**How to apply:** para grupos de opciones en la web, usar filas tipo `.segmento` (como Zonas, Escenas y modos de video). Si un diseño se aparta de eso, explicarlo al proponerlo. Ver [[sin-emojis-en-ui]], [[probar-ui-antes-de-entregar]].
