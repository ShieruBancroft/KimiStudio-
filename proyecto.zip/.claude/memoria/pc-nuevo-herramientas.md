---
name: pc-nuevo-herramientas
description: "Herramientas del PC nuevo (oct 2026): node instalado por winget, git necesita administrador, Edge headless para capturas, pypdf para leer los PDF"
metadata:
  node_type: memory
  type: reference
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-30T20:09:48.437Z
---

PC nuevo desde el 2 oct 2026 (Windows 11 IoT LTSC, PowerShell 5.1, Python 3.14):

- `node` v24 instalado con `winget install OpenJS.NodeJS.LTS`. Ruta: `C:\Program Files\nodejs\node.exe` (no estaba en el PATH de la sesión; usar la ruta completa).
- `git`: `winget install Git.Git` falla sin administrador (exit 12). Funciona MinGit portable: `winget install Git.MinGit --scope user`. Ruta (no está en el PATH de la sesión, usar completa): `C:\Users\MikuPC\AppData\Local\Microsoft\WinGet\Packages\Git.MinGit_Microsoft.Winget.Source_8wekyb3d8bbwe\cmd\git.exe`. Remoto: https://github.com/kasproduction/proyecto-manhatan-steven.git (privado; el PC nuevo necesita credenciales de GitHub para el push).
- Playwright para Python instalado el 25 oct 2026 (`pip install playwright pyserial`); usar `pw.chromium.launch(channel="msedge")`, sin descargar navegadores. Para probar la página sin la Pi: servidor `http.server` que simula `/api/*` y sirve `pi/static/index.html` (fácil de rehacer).
- `node` y `git` sí están en el PATH ahora (25 oct). `arduino-cli`: ver [[esp32-carga-firmware]].
- Los PDF del repo no se renderizan (sin poppler): `pip install pypdf` y extraer texto (script `pdf2txt.py` de la sesión; fácil de rehacer).
- Llave SSH `~/.ssh/id_ed25519` ya copiada a la Pi (11 oct 2026); `ssh`/`scp` de Windows funcionan sin contraseña (ver [[pi-acceso]]).
- Python en el PATH (`python`); sirve para pruebas HTTP contra la Pi con urllib.
- 30 oct: con Playwright sync y `page.route` para simular la API, esperar con `page.wait_for_timeout`, nunca `time.sleep` (bloquea las rutas y da estados viejos). Con `python -I` poner `sys.stdout.reconfigure(encoding="utf-8")` (el `−` y `°` rompen cp1252). Mensajes de commit con comillas: escribirlos a un archivo y `git commit -F` (PowerShell 5.1 parte el here-string).

Ver [[probar-ui-antes-de-entregar]].
