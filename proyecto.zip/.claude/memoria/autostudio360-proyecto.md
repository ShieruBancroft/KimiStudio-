---
name: autostudio360-proyecto
description: "Proyecto Manhatan = AutoStudio 360 (cabina de fotos/video 360 universitaria); arquitectura, estado al 8 nov 2026 y decisiones"
metadata:
  node_type: memory
  type: project
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-11-09T04:25:13.366Z
---

Proyecto universitario (Soluciones Tecnológicas, 2026-2, entrega final semana 12 ≈ 26 oct–1 nov 2026). Repo privado: github.com/kasproduction/proyecto-manhatan-steven. Documentos de continuidad en el repo: ROADMAP.md, BITACORA.md, BUGS.md, PRUEBAS.md, README.md.

Arquitectura: Raspberry Pi 3 **B+** como cerebro + 1 ESP32 en placa de bornera (motor NEMA17/TMC2208 + luces en 2 zonas con 4 módulos MOS D4184) + Insta360 Link 2 + 4 torres COB CCT 12 V. Pines y cableado en [[guia-armado-decisiones]].

Estado al 2 oct 2026:
- Pi con Pi OS Lite 64-bit (Debian 13), Kingston 16 GB, hostname Shieru-i, usuario shieru. Ver [[pi-acceso]].
- Servicio `pi/` funcionando: cámara (vista previa 480p, fotos 4K, video 1080p H.264, PTZ por ioctl, 5 posiciones), web (puertos 80 y 8000, sin emojis, ver [[sin-emojis-en-ui]]), bot de Telegram privado, arranque por systemd. Ventilador y fuente nueva (26 sep).
- Red: WiFi de casa principal; red propia `AutoStudio360` (5 GHz, clave 12345678 desde el 11 oct 2026 (de prueba; WPA2 exige 8+ caracteres), 10.42.0.1) con toggle "Presentación" y portal cautivo.
- Piezas: llegaron 10 módulos MOS, ESP32 USB-C con bornera y cinta COB (2 oct). En camino hasta el 26 oct: motor, TMC2208 (variante DIY, pines sin soldar), kit protoboard, segundo ESP32. Falta ferretería (fuente 12 V con jack, barras, perfiles, cable, condensador, rodamientos, cable USB de datos).
- Guía de armado HTML y firmware único escritos el 2 oct; firmware sin compilar. Ver [[siguiente-paso]].
- 11 oct: archivos de la Pi dañados por bajo voltaje (reemplazados desde el repo); botón "Apagar" en la web para no desenchufarla encendida. El usuario no quiere comandos para operar la Pi: todo desde la web.

- 25 oct: el usuario corrigió la guía de cableado (desde el paso 8, protoboard vs TMC2208) → `AutoStudio_360_Armado_paso_a_paso.html` + `.md` es la vigente. Firmware en el ESP32; 4 torres armadas y probadas (un puente de estaño C–W en una cinta de adelante mezclaba colores; corregido). Web con menús Cámara / Base / Luces y 4 escenas (Cálido 3200, Contraluz 4300/6500, Producto 5000, Luz día 5600). Luces y base solo en la web, no en el bot (pedido del usuario). TMC2208 y protoboard ya los tiene; el motor no está a mano.

- 30 oct: base giratoria funcionando (TMC2208 + NEMA17 17HS4401 directo al plato, Vref 1,12 V, ~450 g sin perder pasos; sin sensor Hall). Video coordinado con la base y botón Cancelar en la web ([[video-con-base]]). Escenas de luz en fila de botones. Informes para el docente ([[informes-docente]]).

- 8 nov: cubo armado. Orientación Horizontal/Vertical en el menú Cámara para figuras altas (el usuario gira el trípode); vertical = 9:16 completo ([[orientacion-vertical]]).

Decisiones:
- Dirección para navegadores en números, `http://10.42.0.1` (autostudio.lan no resuelve en Android con datos móviles). Sin dominio público.
- La Pi 3B+ tiene un solo radio WiFi: o red propia o internet. Para ambos: cable o adaptador WiFi USB (sin decidir).
- La microSD "125 GB" de AliExpress es falsa (~4 GB reales): no usar.

**Why:** evita re-diagnosticar la Pi y re-decidir red, pines y cableado.
**How to apply:** leer [[siguiente-paso]] al retomar; no desconectar la Pi durante un primer arranque; reportar estado según [[estado-sin-tiempos]].
