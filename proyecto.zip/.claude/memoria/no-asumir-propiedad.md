---
name: no-asumir-propiedad
description: No asumir que dominios o cuentas mencionados en skills/config son del usuario
metadata:
  node_type: memory
  type: feedback
  originSessionId: 461604e5-0279-42b3-a066-6bdff6749ef4
  modified: 2026-10-03T00:47:21.890Z
---

No suponer que un dominio, cuenta o servicio es del usuario solo porque aparece en una skill o configuración: preguntar antes de proponer usarlo.

**Why:** el 26 sep 2026 se propuso crear un subdominio en kasproduction.tech y el usuario aclaró "esto no es mío".
**How to apply:** antes de proponer DNS, hosting o cuentas externas, confirmar de quién son.
