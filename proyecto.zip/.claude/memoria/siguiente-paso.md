---
name: siguiente-paso
description: "Punto de reanudación de AutoStudio 360 tras el 8 nov 2026: cubo armado, orientación vertical lista; sigue confirmar flechas/Telegram en vertical, video con base en la cabina y sensor Hall"
metadata:
  node_type: memory
  type: project
  originSessionId: a8d4c564-68b8-40a5-9351-c7fe0d362d13
  modified: 2026-11-09T04:25:09.916Z
---

Cerrado el 8 nov 2026: el usuario terminó de armar el cubo. Orientación Horizontal/Vertical en la web, desplegada y probada con la cámara real (ver [[orientacion-vertical]]). La Pi estaba en `192.168.1.7` con la red `AutoStudio360` activa en wlan0 y el PC por cable; este PC tiene guardado el perfil WiFi de `AutoStudio360`.

Push: el usuario hace `git push` en una ventana aparte de PowerShell (GitHub pide credenciales). Revisar con `git log origin/main..HEAD` si quedó algo sin subir.

Siguiente bloque, en este orden:
1. Que el usuario confirme que, en Vertical, cada flecha mueve la imagen hacia donde apunta (si no, ajustar el mapeo en `Camara.mover`). Probar un video vertical por el bot de Telegram; si llega acostado, mandar siempre una copia recodificada en vertical.
2. Probar los 4 modos de video y Cancelar con la base en la cabina: que la Vuelta 360 empiece de frente (`MARGEN`/`retardo` en `rodaje.py`) y que el video empalme en bucle. Ver [[video-con-base]].
3. Sensor Hall (paso 34): probar el A3144 a 3,3 V con el imán; luego `HOME` y, si sirve, que la Pi mande `HOME` al arrancar.
4. Asegurar el conector del motor; pruebas de carga 1–3 kg (si pierde pasos, Vref a 1,2 V).
5. Revisar las 4 escenas de luz en la cámara.

Al encender: primero la Pi (el ESP32 va por su USB), después el 12 V; poner el plato en la marca y "Marcar cero aquí".

Preguntas abiertas: confirmación del docente PC→Pi; botones de luces/base en el bot (por ahora solo web). Idea aprobada para después: Fotos 360 (24 fotos cada 15° + visor).

Leer primero: BITACORA.md (8 nov), ROADMAP.md, [[pi-acceso]], [[orientacion-vertical]].
