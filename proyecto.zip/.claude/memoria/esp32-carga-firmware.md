---
name: esp32-carga-firmware
description: Cómo compilar y subir el firmware al ESP32 desde el PC nuevo con arduino-cli; la placa necesita BOOT/EN a mano; cómo hablarle por serial sin reiniciarlo
metadata:
  node_type: memory
  type: reference
  originSessionId: a5c70fa5-f8d9-4cf2-a3c3-dc7ef8ddc710
  modified: 2026-10-30T20:09:45.382Z
---

- `arduino-cli` instalado el 25 oct 2026 (`winget install ArduinoSA.CLI`); recargar el PATH en la sesión: `$env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User")`. Núcleo `esp32:esp32` y FastAccelStepper 2.0.1 ya instalados.
- Compilar: `arduino-cli compile --fqbn esp32:esp32:esp32 esp32\AutoStudio360`. Subir: `arduino-cli upload -p COM3 --fqbn esp32:esp32:esp32 esp32\AutoStudio360`.
- La placa CH340C no entra sola en modo de carga ("Wrong boot mode detected (0x13)") ni se reinicia sola al final. Lo que funcionó: lanzar la carga en bucle en segundo plano y que el usuario mantenga BOOT presionado ~15 s; al terminar, que presione EN. BOOT+EN antes de lanzar no sirve (el reinicio de esptool lo saca del modo).
- Hablarle desde PowerShell sin reiniciarlo: `System.IO.Ports.SerialPort` COM3 115200 con `DtrEnable=$false` y `RtsEnable=$false`. Con DTR/RTS por defecto se reinicia al abrir.
- En la Pi lo maneja `pi/esp32.py` (busca `/dev/ttyUSB*`, exige `PONG`). Rutas: `/api/esp32`, `/api/luces`, `/api/base`. Desde el PC: `Invoke-RestMethod` contra la Pi (curl dentro de ssh rompe las comillas del JSON).
- Venía con firmware AT de fábrica.
- 30 oct: para probar la base desde el PC se usó un script PowerShell con `param([string]$Port, [int]$Timeout, ...$Cmds)` que espera `DONE`/`ERR`; pasar siempre `-Port COM3` con nombre (si no, el primer comando se toma como puerto). `TURN` exige segundos (`TURN 12`). Opening a serial con DTR/RTS apagados no reinicia el ESP32; el `esp32.py` de la Pi sí lo reinicia al conectarse (el plato puede saltar: volver a marcar el cero).

Ver [[guia-armado-decisiones]], [[pi-acceso]].
