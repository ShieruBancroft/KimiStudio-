---
name: video-con-base
description: "Diseño del video coordinado con la base (pi/rodaje.py, 30 oct 2026): modos, límites, sincronización con ffmpeg y botón Cancelar"
metadata:
  node_type: memory
  type: project
  originSessionId: cabbdc4c-a759-4f02-a006-399a90593630
  modified: 2026-10-30T20:09:27.620Z
---

Aprobado por el usuario el 30 oct 2026 y desplegado en la Pi; probado solo en simulación y Playwright.

- Menú Cámara → fila "Base durante el video": Quieta / Vuelta 360 / Paradas / Vaivén (localStorage `modoBase`). `POST /api/grabar {segundos, base}`; `POST /api/grabar/cancelar`. `/api/estado` trae `esp32`, `video_base`, `fase` (preparando/grabando/volviendo), `base_ocupada`.
- Vuelta 360: `GOTO` a un ángulo negativo, `ACCEL 90`, `SPIN 360/T`, y después la grabación; así el video no tiene rampas y queda en bucle. El ángulo previo usa `cam.retardo` (s de pedir el video al primer cuadro, media móvil, arranca en 1,0), medido con `ffmpeg -progress pipe:1 -stats_period 0.1`.
- Paradas: `SPEED 60`, `ACCEL 120`, 4 × `ROT 90` (2,0 s cada uno) repartidos en T. Vaivén: +45 / −90 / +45 con rampas de 1/3, al 95 % de cada tramo.
- Con 5 s, Vuelta y Paradas se rechazan (límite de 60 °/s del firmware; el firmware NO se tocó).
- Al terminar o cancelar: `STOP`, se restauran SPEED/ACCEL previos (de `STATUS`), `GOTO 0`. Cancelar borra el mp4 a medias; si era del bot, el bot avisa.
- Durante un video con base, `/api/base` responde 409 y el menú Base queda bloqueado.

**Why:** el usuario quiere videos de presentación de producto sin tener que mover la base a mano, y no gastar memoria en videos fallidos.
**How to apply:** al probar en la cabina, ajustar constantes en `rodaje.py` (`MARGEN`, `ACEL_VUELTA`, `ACEL_PARADA`) y el JS (`VEL_MAX`, `GIRO_PARADA`) en los dos lados. Ver [[siguiente-paso]], [[guia-armado-decisiones]].
