---
name: orientacion-vertical
description: "Orientación de la cámara (8 nov 2026): botones Horizontal/Vertical, cómo gira la Pi foto/video/vista previa, y por qué se descartaron Derecha/Izquierda, el recorte 4:5 y el 16:9 con bandas"
metadata:
  node_type: memory
  type: project
  originSessionId: a8d4c564-68b8-40a5-9351-c7fe0d362d13
  modified: 2026-11-09T04:25:02.914Z
---

Para figuras altas el usuario gira el **trípode** 90° (siempre hacia el mismo lado) y en la web toca **Vertical** (menú Cámara → Orientación). Para volver, gira el trípode y toca **Horizontal**. La Pi no detecta la posición de la cámara; el ajuste queda en `~/autostudio/ajustes.json` (`{"giro": 0|90}`).

Implementación (`pi/camara.py`, `set_giro`, constantes `VERTICAL=90` y `FILTRO_VERTICAL="transpose=1"`):
- La vista previa lleva `transpose=1` después del scale de 480p; la foto se gira con ffmpeg (`-f mjpeg -i pipe:0 -vf transpose=1 -q:v 2`): 4K → 2160×3840, ~3,6 s en total.
- Video sin recodificar: `-display_rotation:v:0 -90` antes de `-i` (ffmpeg 7.1 de la Pi). ffprobe muestra 1920×1080 con rotation=-90; Edge lo reproduce derecho.
- `version_liviana` usa `scale=1280:1280:force_original_aspect_ratio=decrease:force_divisible_by=2` (ffmpeg autorrota al decodificar).
- `mover()` interpreta las flechas como dirección en pantalla: en vertical pan=-y, tilt=x (sirve para la web y el bot).
- En vertical se rechaza/oculta el formato "vertical" (2176×3840, es un recorte del sensor y saldría acostado).
- `POST /api/giro {grados}` (rechaza si hay captura o video con base); `/api/estado.giro`.

Descartado:
- Derecha/Izquierda: el usuario solo usa dos posiciones.
- Recorte 4:5 (2/3 del corte arriba para no ver el techo de la caja): funcionaba, incluso el video sin recodificar con `-bsf:v h264_metadata=crop_left=380:crop_right=190`. Lo quitó porque "queda muy pequeña la imagen". Si vuelve el techo, mejor bajar la cámara o usar zoom.
- 16:9 con bandas: el video habría que recodificarlo en la Pi.

**Why:** evita volver a ofrecer opciones ya descartadas y volver a buscar cómo rotar sin recodificar.
**How to apply:** pendiente que el usuario confirme las flechas en vertical y el video vertical por Telegram (el bot manda el original si pesa <48 MB). Ver [[siguiente-paso]], [[video-con-base]].
