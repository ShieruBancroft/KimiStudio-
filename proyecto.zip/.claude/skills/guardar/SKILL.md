---
name: guardar
description: Cierre de sesión de trabajo en tres pasos — 1) commit y push, 2) documentar (bitácora, bugs, pruebas, roadmap, arquitectura), 3) guardar todo el contexto en la memoria de Claude — para que la siguiente sesión arranque con /continuar sin reprocesar nada. Invocar con /guardar al terminar un bloque de trabajo o antes de cerrar la sesión.
---

# /guardar — cierre de sesión

Distinto de `/davinci` (que es cómo se trabaja). `/guardar` es cómo se **cierra**: nada del trabajo queda solo en la conversación. Los tres pasos son obligatorios y se ejecutan en este orden. Al final se reporta en 5 líneas máximo.

## Paso 1 — Código: commit y push

1. `git status` en el repo del proyecto. Si no hay repo, proponer crearlo (no crearlo solo).
2. Verificar que NO entren secretos ni artefactos: `.env`, `vendor/`, `node_modules/`, `dist/`, llaves, dumps. Si algo así está trackeado, detenerse y avisar.
3. Correr los tests del proyecto. Si fallan, igual se hace commit, pero el mensaje lo dice y queda en BUGS.md.
4. Commit con mensaje en español: título de una línea con qué cambió y por qué, cuerpo con viñetas por módulo. Firma `Co-Authored-By` como pide el entorno.
5. `git push` al remoto si existe. Si no existe remoto, decirlo en el reporte y proponer crearlo (es acción hacia afuera: esperar "dale").

## Paso 2 — Documentación del proyecto

Actualizar los archivos de continuidad del repo (nombres por defecto; si el proyecto usa otros, respetar los suyos):

| Archivo | Qué se escribe |
|---|---|
| `BITACORA.md` | Entrada del día arriba: **Decisiones**, **Hecho** (con ids del roadmap), **A medias / pendiente inmediato**, **Sigue**. |
| `BUGS.md` | Cada bug encontrado o corregido: síntoma, causa, corrección, test. Abiertos arriba. |
| `PRUEBAS.md` | Suites nuevas o cambiadas y una fila en el historial de resultados con fecha y cifra. |
| `ARCHITECTURE.md` | Solo si cambió una decisión: qué, por qué, qué se descartó. |
| `CONTINUIDAD.md` | Solo si cambió dónde está algo, un acceso o un contacto. |
| Roadmap del proyecto | Marcar tareas hechas / en curso, agregar tareas nuevas, verificar dependencias. Si el roadmap es un HTML con estado embebido, actualizar el `<script id="state">` con la fecha del día. |

Los cambios de documentación entran en el mismo commit del paso 1 (o en uno aparte "Cierre de sesión: documentación" si el paso 1 ya se hizo).

## Paso 3 — Memoria de Claude

Guardar en la memoria del proyecto (`MEMORY.md` + archivos con frontmatter) todo lo que la siguiente sesión necesita para no reprocesar:

1. **Estado del proyecto:** actualizar el archivo de estado/pendientes con fecha absoluta: qué se cerró hoy, qué quedó abierto, en qué orden sigue. Enlazar con `[[...]]` a las memorias relacionadas.
2. **Decisiones nuevas** del usuario: una memoria `project` por decisión importante (qué, por qué, qué se descartó).
3. **Feedback** recibido sobre la forma de trabajar: memoria `feedback` con **Why** y **How to apply**.
4. **Referencias:** rutas nuevas, URLs, comandos que cuestan redescubrir.
5. **Punto de reanudación:** una memoria (o sección) llamada "siguiente paso" con: el bloque exacto que sigue, qué aprobó el usuario, qué preguntas quedaron abiertas, y los archivos que hay que leer primero. Es lo que `/continuar` carga.
6. Verificar que `MEMORY.md` tenga una línea por memoria nueva y que no queden duplicados ni memorias vencidas (borrar o corregir las que ya no son ciertas).

## Reporte final (máximo 5 líneas)

- Commit `<hash corto>` y si se hizo push (o que falta remoto).
- Documentos actualizados (nombres).
- Memorias escritas o actualizadas (nombres).
- Tests: cifra.
- Lo primero que hará `/continuar`.

## Reglas

- Nunca hacer push a un remoto que no exista sin aprobación explícita.
- Nunca meter secretos en git ni en memoria.
- Si el usuario dice "guarda" o "guardamos" o "cerremos", es `/guardar`.
- Trabajo autónomo: no preguntar en medio de los tres pasos salvo por secretos expuestos o remoto inexistente.
