---
name: continuar
description: Arranque de sesión — carga el contexto guardado por /guardar (memoria, bitácora, roadmap, estado del repo) y propone el siguiente bloque de trabajo sin reprocesar nada. Invocar con /continuar (o /siguiente, /anterior) al empezar una sesión en un proyecto en curso.
---

# /continuar — retomar donde quedamos

Es el reverso de `/guardar`. El objetivo es que en menos de un minuto el usuario vea **dónde estamos, qué sigue y qué falta decidir**, sin releer documentos largos ni volver a explicar el proyecto.

## Qué leer (en este orden, sin resumirlo en voz alta)

1. `MEMORY.md` del proyecto y las memorias que apunten al estado, los pendientes y el "siguiente paso" (lo escribió `/guardar`).
2. La última entrada de `BITACORA.md` del repo (o el archivo de bitácora que use el proyecto).
3. `git log --oneline -5` y `git status --short` del repo: ¿hay cambios sin commit? ¿el último commit coincide con la bitácora?
4. El roadmap del proyecto: tareas en curso y las "listas" (dependencias cumplidas), en especial las de ruta crítica.
5. `BUGS.md`: abiertos.
6. Solo si el siguiente paso lo requiere: los archivos de código que la memoria marcó como "leer primero".

No leer el documento de arquitectura completo ni el código entero: para eso está la memoria. Si algo de la memoria contradice al repo, manda el repo y se corrige la memoria.

## Qué decir (máximo 12 líneas)

```
**Dónde estamos:** <una frase: último bloque cerrado y fecha>.
**Estado del repo:** <commit corto, limpio / con cambios sin commit>. Tests: <cifra>.
**Abierto:** <decisiones pendientes del usuario o del cliente, en una línea cada una; máximo 3>.
**Sigue (aprobado):** <el bloque exacto que el usuario ya aprobó en la sesión anterior>.
**Propongo hoy:** <1–3 pasos concretos, con ids del roadmap>.
¿Arranco con eso?
```

Si el usuario invocó `/anterior`, mostrar además las 3 últimas entradas de la bitácora en una línea cada una.

## Reglas

- Tutear al usuario y hablar en español neutro.
- No repetir el contexto del proyecto (qué es, para quién): el usuario lo sabe. Solo estado y siguiente paso.
- Si la sesión anterior dejó una pregunta sin responder, hacerla primero, corta.
- Si no hay memoria de "siguiente paso", decirlo y proponer a partir del roadmap.
- Después del "dale" del usuario, trabajar en modo `/davinci` para lo no trivial y cerrar con `/guardar`.
