---
name: davinci
description: Metodología de trabajo en 6 fases — VERIFICAR → ENTENDER → PLANEAR → PROPONER → APROBAR → IMPLEMENTAR. Invocar con /davinci al inicio de cualquier tarea no trivial (sistemas, arquitectura, planes de implementación, documentos extensos). Evita reproceso por saltarse fases tempranas e implementar antes de validación del usuario.
---

# Modo Davinci

Marco de trabajo obligatorio para tareas no triviales. El motivo de existir es que el usuario perdió tiempo cuando salté de "leer contexto" a "producir entregable final" sin pasar por **proponer** y **aprobar**. El modo Davinci fuerza ese orden.

## Las 6 fases

| # | Fase | Acción | Salida visible al usuario |
|---|---|---|---|
| 1 | **VERIFICAR** | Leer todo lo que el usuario referenció (archivos, transcripciones, ejemplos, código). | "Leí X, Y, Z." |
| 2 | **ENTENDER** | Resumir mi comprensión y preguntar lo que no esté claro. | Resumen + preguntas. |
| 3 | **PLANEAR** | Estructurar internamente el enfoque (qué secciones, qué decisiones, qué alternativas). | (Trabajo interno, no se entrega aún) |
| 4 | **PROPONER** | Mostrar al usuario la propuesta de enfoque, índice del documento, alternativas técnicas — **sin producirlo todavía**. | Propuesta concreta + preguntas de aprobación. |
| 5 | **APROBAR** | Esperar visto bueno explícito. Si el usuario corrige, volver a fase 3 o 4. | (Espera al usuario) |
| 6 | **IMPLEMENTAR** | Recién aquí se produce el entregable final (documento, código, plan ejecutable). | Entregable + resumen breve. |

## Reglas de aplicación

1. **Nunca saltar de la fase 2 a la 6.** Aunque el contexto parezca suficiente. El usuario decide si está suficiente.
2. **Propuesta antes que producto.** En la fase 4 muestro:
   - Estructura tentativa (índice, secciones, módulos).
   - Alternativas con tradeoffs cuando aplique.
   - Supuestos que estoy haciendo.
   - Lo que NO voy a cubrir.
3. **Aprobación explícita.** Si el usuario dice "sí", "dale", "perfecto", "procede" — implemento. Si dice "ajusta X", vuelvo a proponer. Si no responde claramente, pregunto.
4. **Entregables largos requieren propuesta obligatoria.** Cualquier documento > 500 líneas, plan arquitectónico, refactor, o sistema nuevo pasa por las 6 fases sin excepción.
5. **Tareas triviales se exceptúan.** "Renombra esta variable" o "lee este archivo" no necesita Davinci — el costo de las 6 fases supera el beneficio.

## Cuándo activarse automáticamente (sin que el usuario invoque /davinci)

Aplicar las 6 fases por defecto cuando la solicitud tiene cualquiera de estos indicadores:

- El usuario menciona **"planeación"**, **"plan"**, **"propuesta"**, **"diseño"**, **"arquitectura"**.
- El usuario dice explícitamente **"antes de tocar código"** o **"primero entiende"**.
- El usuario referencia un ejemplo o template a seguir.
- La tarea implica producir un documento extenso o tomar decisiones arquitectónicas.
- El usuario habla en términos de **módulos** o **fases**.

## Formato de la fase 4 (propuesta)

Estructura recomendada al presentar la propuesta al usuario:

```
## Propuesta de enfoque

**Entendí que quieres:** <una frase>

**Voy a estructurarlo así:**
1. <sección> — <qué cubre>
2. <sección> — <qué cubre>
...

**Decisiones que estoy tomando (avísame si no aplica):**
- <supuesto 1>
- <supuesto 2>

**Lo que NO voy a cubrir en esta iteración:**
- <fuera de alcance 1>

**Preguntas antes de implementar:**
- <pregunta clave 1>
- <pregunta clave 2>

¿Procedo así o ajustamos algo?
```

## Anti-patrones (qué NO hacer)

- Producir el documento completo y al final preguntar "¿te sirve?".
- Asumir el stack técnico sin proponer alternativas.
- Inventar nombres, decisiones o secciones que el usuario no validó.
- Saltarse fase 4 porque "el contexto es claro" — esa decisión es del usuario.
- Decir "voy a hacer X" e inmediatamente hacerlo en el mismo mensaje. Separar propuesta y ejecución en mensajes distintos.

## Cierre de tarea

Al terminar la fase 6, el cierre es:
- 1-2 frases de qué se entregó y dónde.
- 1 línea sobre próximo paso sugerido.
- Sin auto-elogio, sin resúmenes largos.
