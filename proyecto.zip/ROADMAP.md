# Roadmap · AutoStudio 360 (versión Raspberry Pi)

Semestre 2026-2. Semanas contadas desde el 10 de agosto, igual que el cronograma de la primera entrega.
Arquitectura: Raspberry Pi 3 (cerebro + página web) · 1 ESP32 (motor + luces) · Insta360 Link 2 · 4 torres en 2 zonas.
Detalle en `AutoStudio360_Comparativo.html`.

## Hecho

- [x] Problemática, evidencias y primera entrega (1 sep)
- [x] Guías de armado de luces y base giratoria
- [x] Compra de motor, driver, sensor Hall, 2 ESP32, cinta COB CCT y 10 módulos MOS
- [x] **Llegaron los 10 módulos MOS, el ESP32 con placa de bornera y la cinta COB** (2 oct): inventario y enlaces en "Inventario recibido" (abajo)
- [x] **Control PTZ de la Link 2 desde Python validado en Windows** (26 sep): pan −145…145, tilt −90…100, zoom 100…400
- [x] Comparativo PDF vs. versión simplificada y repositorio
- [x] **Raspberry Pi 3 B+ funcionando** (26 sep): Pi OS Lite 64 bits, SSH por llave, WiFi de casa + red propia `AutoStudio360` (5 GHz) de respaldo
- [x] **Link 2 validada en la Pi** (26 sep): foto 4K (horizontal y vertical), video 1080p H.264 sin recodificar, PTZ por ioctl
- [x] **Servicio `pi/`** (26 sep): página web con vista previa, PTZ continuo, 5 posiciones, galería con miniaturas; bot de Telegram; arranque automático
- [x] **Modo presentación y portal cautivo** (26 sep): toggle en la web, red `AutoStudio360` con bienvenida y `http://10.42.0.1`
- [x] **Guía de armado completa** (2 oct): `AutoStudio360_Guia_Armado.html`, cableado paso a paso de luces (29 pasos) y base (21 pasos), tabla de pines, barras, Vref, primer encendido
- [x] **Firmware único escrito** (2 oct): `esp32/AutoStudio360/AutoStudio360.ino`, motor + luces en 2 zonas. Falta compilarlo y subirlo
- [x] **Luces terminadas y controladas desde la web** (25 oct): firmware v2.0 en el ESP32, 4 torres probadas, menús Cámara / Base / Luces en la página
- [x] **Base giratoria funcionando** (30 oct): TMC2208 + NEMA17 en protoboard, plato directo; probada por serial y desde el menú Base, con ~450 g sin perder pasos
- [x] **Video coordinado con la base** (30 oct): modos Quieta / Vuelta 360 / Paradas / Vaivén y botón Cancelar en la web (`pi/rodaje.py`). Falta probarlo con la cámara y la base armada
- [x] **Cubo armado y orientación vertical** (8 nov): botones Horizontal / Vertical en el menú Cámara; en vertical la Pi gira la vista previa, las fotos (2160×3840) y el video (sin recodificar) y reasigna las flechas. Falta confirmar las flechas y el video vertical por Telegram
- [x] **Página de la Pi reparada y botón Apagar** (11 oct): archivos dañados en la SD reemplazados por los del repo; apagado seguro desde la web; clave de `AutoStudio360` = `12345678` (de prueba)

## Semana 8 · 28 sep – 4 oct · Compuerta Raspberry

La integración no avanza hasta pasar esta compuerta.

- [ ] Confirmar con el docente el cambio de computador a Raspberry Pi
- [x] Comprar lo de la lista "Para probar la Raspberry" (abajo): microSD Kingston 16 GB, fuente nueva y cable de la Link 2 ya en uso (26 sep)
- [x] Instalar Raspberry Pi OS Lite (64 bits) con WiFi y SSH desde Raspberry Pi Imager
- [x] **Prueba de la cámara en la Pi:** `v4l2-ctl --list-formats-ext` muestra 1080p MJPEG y `v4l2-ctl -c pan_absolute=36000` mueve la cámara
- [x] Tomar una foto 1080p y grabar 20 s de video desde la Pi; revisar que no se corten cuadros
- [ ] Definir el tamaño de la cabina: 40 × 40 cm (guía de luces) o 60 × 60 cm (entrega)
- [ ] Mandar a imprimir la base giratoria (~8 h)

**Si la Pi falla:** se sigue con el computador. El software es el mismo Python; solo cambia dónde corre.

## Semana 9 · 5 – 11 oct · Base y firmware

- [ ] Armar la base: rodamientos, motor, acople (guía de base, sección 09)
- [x] Ajustar Vref del TMC2208 (30 oct: 1,12 V)
- [x] Pruebas 1 a 5 de la guía de base (30 oct: programa, Vref, motor, base con plato pequeño, temperatura)
- [ ] Sensor Hall (paso 34 de la guía nueva): probar el A3144 a 3,3 V y luego `HOME`
- [ ] Asegurar el conector del motor (se soltó en la protoboard el 30 oct)
- [x] Firmware único en el ESP32 escrito: BaseGiratoria + luces en 2 zonas (pines 18/19 y 23/32) → `esp32/AutoStudio360/`
- [x] Compilar y subir el firmware (25 oct, `arduino-cli`, núcleo esp32 + FastAccelStepper 2.0.1); `PING` → `PONG`. La placa necesita BOOT/EN a mano para cargar
- [x] En la Pi: portar `ptz.py` a Linux (v4l2) → `pi/camara.py`
- [x] En la Pi: `pi/esp32.py` (pyserial, `/dev/ttyUSB0`, se reconecta solo) y menús Base y Luces en la web (25 oct)
- [ ] Botones de luces y giro en el bot de Telegram (el usuario pidió por ahora solo la web)
- [x] Probar el menú Base con el TMC2208 y el motor conectados (30 oct)
- [ ] Probar los modos de video con base y Cancelar con la cámara y la base armada

## Semana 10 · 12 – 18 oct · Luces y página web

- [x] Cortar 4 tramos de 35 cm de cinta y soldar los 3 cables en los 3 tramos que no los traen (9 soldaduras)
- [x] Soldar el cable de señal (TRIG/PWM) en 4 módulos MOS; los otros 6 quedan de repuesto
- [x] Armar las 4 torres y probarlas (25 oct, guía nueva `AutoStudio_360_Armado_paso_a_paso.html` pasos 1–24): zonas separadas, frío y cálido correctos, rampas de tono y brillo
- [x] Luces desde la Pi: menú Luces con zona, brillo, tono, 4 escenas de foto y `TEST` (25 oct)
- [x] Armar la Parte 8 de la guía nueva: TMC2208, jumpers, condensador, 12 V, Vref, bobinas y motor (pasos 25–33) y revisión del paso 35 (30 oct)
- [ ] Revisar en la cámara las escenas Cálido / Contraluz / Producto / Luz día y ajustar porcentajes
- [x] Página web en la Pi: vista previa en vivo, botón Capturar, galería con descarga al celular
- [ ] Bloquear exposición, balance de blancos y foco de la cámara durante la captura
- [ ] Programas automáticos: GPU, Figura y Detalle (preset de cámara + luz + 8 fotos + video de 20 s)
- [ ] Probar la página en celular, tablet y TV de 27" (celular OnePlus: OK)
- [ ] Seguridad antes de la sustentación: contraseña de la Pi, SSH solo por llave, `/revoke` del token del bot, clave de `AutoStudio360`

## Semana 11 · 19 – 25 oct · Integración y validación

- [ ] Montar todo en la cabina (8 nov: cubo armado)
- [ ] Orientación vertical: confirmar las flechas de la cámara y el video vertical por Telegram
- [x] Arranque automático del servicio al prender la Pi
- [ ] Pruebas de carga de la base con 1, 3 y 5 kg
- [ ] **Validación con 10 productos** (GPU y coleccionables), cronometrando de "pongo el objeto" a "fotos en el celular". Meta: menos de 2 min
- [ ] Actualizar el documento: Pi, base 1:1, MOSFET D4184, 2 zonas, tamaño final, resultados
- [ ] Evidencias: fotos del cableado, video del `TEST`, tabla de tiempos

## Semana 12 · 26 oct – 1 nov · Entrega final

- [ ] Ensayo de la sustentación con la TV de 27" como monitor
- [ ] Holgura para repuestos y repetir pruebas
- [ ] Entrega final y sustentación

## Opción Pro · solo si lo básico ya funciona

Mejoras para después de la validación o como plus para la sustentación. No bloquean nada del plan principal.

- [ ] **Bot de Telegram:** botones GPU / Figura / Detalle / Luces; la Pi envía al chat las 8 fotos como álbum, los originales como archivo y el video en H.264 (menos de 50 MB)
- [ ] **Fotos 360:** 24 fotos 4K, una cada 15°, y un visor que se gira con el dedo (la Pi alcanza; ~1 min por objeto dejando la cámara abierta)
- [x] **Encuadre por Telegram:** botón "Ver cámara" con flechas y zoom que mueven la cámara y actualizan la foto en el mismo mensaje
- [x] **Video en vivo por WiFi** en `http://<ip-de-la-pi>:8000` (reenvío del MJPEG de la cámara) para la TV de 27" o la tablet
- [ ] Solo chats autorizados pueden usar el bot; si no hay internet, se captura igual y se envía al volver la conexión
- [x] Un solo programa en la Pi dueño de la cámara que reparte los cuadros al bot, al video en vivo y a la captura

Antes de empezar: crear el bot con @BotFather y guardar el token fuera del repositorio.

## Compras pendientes

### Para probar la Raspberry (semana 8)

| Artículo | Nota |
|---|---|
| MicroSD 32 GB, clase A1 | 16 GB alcanza, 32 GB da espacio para videos |
| Fuente 5 V / 2,5 A con micro-USB | La Pi 3 se alimenta por micro-USB; un cargador de celular normal se queda corto |
| Cable USB-C a USB-A (datos) | La Pi 3 solo tiene USB-A; revisar si la caja de la Link 2 ya trae uno o un adaptador |
| Lector de microSD | Solo si el computador no tiene ranura |

### Para armar la cabina (de las guías, si no lo tienen)

| Artículo | Cantidad |
|---|---|
| Adaptador 12 V / 5 A + jack DC hembra con bornera | 1 (las 4 torres a tope consumen ~1,4 A; con 3 A también alcanza) |
| Barras de distribución (o conectores Wago 221) | 2 |
| Perfil de aluminio con difusor | 4 × 35 cm |
| Cable 22 AWG (rojo, negro, azul, amarillo) y 18 AWG (rojo, negro) | ~3 m y 50 cm |
| Termoencogible y cinta aislante | 1 surtido |
| Cautín 30–60 W, estaño con flux 0,8 mm y multímetro | solo si no tienen |
| Condensador electrolítico 100 µF / 35 V | 1 (+1) |
| Rodamientos 6700ZZ | 6 (+2) |
| Tornillos M3 × 8 y M3 × 10 | kit |
| Cable USB-A a USB-C **de datos** para el ESP32 (confirmado USB-C el 2 oct) | 1 (probar con `lsusb` en la Pi: muchos cables de celular solo cargan) |
| MDF para la cabina y tabla de montaje | según tamaño |

Ya no hace falta: segundo juego de módulos, sensor VL53L0X, jumpers dupont (la placa de bornera del ESP32 reemplaza los jumpers por cable 22 AWG), tira de pines para los módulos (el cable de señal se suelda directo) ni un computador junto a la cabina.

## Inventario recibido · 2 oct 2026

| Pieza | Enlace | Llegó | Se usa | Nota |
|---|---|---|---|---|
| Módulo MOS XY-MOS, 2 chips D4184, 5–36 V, 15 A | https://a.aliexpress.com/_msu0fTd | 10 | 4 (zona adelante y zona atrás, frío y cálido) | Bornes de 12 V puestos; la entrada TRIG/PWM viene como huecos vacíos: soldar un cable 22 AWG por módulo. El pin GND junto a PWM ya está unido a VIN− |
| ESP32 30 pines, USB-C, CH340C + placa de bornera MRD068A ("CH340C Set") | https://a.aliexpress.com/_msU2FQL | 1 | 1 | Pines ya soldados. Rótulos de la placa coinciden pin a pin (D18, D19, D23, D32 disponibles). Antena hacia afuera, USB-C al otro lado; alinear 3V3 con 3V3 antes de presionar |
| Cinta COB CCT 12 V, 5 m, 10 mm, 608 LED/m, 2700–6500 K, 11,52 W/m | https://a.aliexpress.com/_mrUqw7v | 1 rollo | 4 tramos de 35 cm (1,4 m) | Un solo extremo trae los 3 cables (rojo +, blanco y amarillo). Por tramo ~4 W / 0,34 A; las 4 torres ~16 W / 1,4 A. Si no quieren soldar: clips de 3 pines para 10 mm |

Soldaduras totales: 4 en módulos + 9 en cinta. Nada más se suelda: el ESP32 va enchufado en la placa y todo lo demás por bornera.

**En camino (pedidos del 2 oct, llegada estimada 14–26 oct):**

| Pieza | Enlace | Nota |
|---|---|---|
| Motor NEMA17 17HS4401, 1,5 A, 42 N·cm, con cable dupont | https://es.aliexpress.com/item/1005008459399126.html | El cable dupont entra directo a la protoboard del TMC2208 |
| Driver TMC2208 BIGTREETECH, variante "DIY" | https://es.aliexpress.com/item/33025652788.html | Llegada hasta el 26 oct. Revisar al abrir si los pines vienen sueltos: la variante DIY suele traerlos sin soldar (16 soldaduras) |
| Kit protoboard mini + jumpers + LED + resistencias | https://es.aliexpress.com/item/32392610240.html | Para montar el TMC2208 |
| Segundo ESP32 CH340C Set | https://es.aliexpress.com/item/1005009523624505.html | Repuesto |

Mientras llega el motor y el driver, la base no se puede armar: adelantar luces y firmware.
