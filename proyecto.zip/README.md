# Proyecto Manhatan · AutoStudio 360

Cabina semi-automatizada de captura de fotos y video 360° para vender componentes de PC y coleccionables en Marketplace / Mercado Libre.
Soluciones Tecnológicas — Licenciatura en Tecnología, 2026-2.

## Contenido

| Archivo | Qué es |
|---|---|
| `Primera entrega Proyecto.pdf` | Documento de la primera entrega (contexto y problemática) |
| `AutoStudio360_Guia_Armado.html` | **Guía de armado vigente** (2 oct): luces en 2 zonas, base giratoria y un solo ESP32, con cableado paso a paso. Reemplaza a los dos PDF para el cableado |
| `AutoStudio360_Guia_Luces_4_Torres.pdf` | Guía de luces de septiembre (4 torres independientes, 8 módulos). Solo referencia |
| `AutoStudio360_Guia_Base_Giratoria.pdf` | Guía de la base de septiembre. Sigue vigente para la impresión 3D y el modelo de MakerWorld |
| `esp32/AutoStudio360/AutoStudio360.ino` | Firmware único del ESP32: motor (TMC2208) + luces en 2 zonas. Comandos por USB serial a 115200 |
| `llego/` | Fotos de las piezas recibidas el 2 oct |
| `AutoStudio360_Comparativo.html` | Arquitectura de los PDF vs. versión simplificada con Raspberry Pi 3 |
| `ptz.py` | Control PTZ de la Insta360 Link 2 por UVC (DirectShow en Windows) |
| `ptz_gui.py` | Interfaz de prueba de la cámara: sliders, teclado, presets y vista previa |
| `ROADMAP.md` | Tareas por semana y compras pendientes |
| `BITACORA.md`, `BUGS.md`, `PRUEBAS.md` | Registro por sesión, errores y pruebas |
| `pi/` | Servicio de la Raspberry Pi: cámara, página web, bot de Telegram y red de respaldo |

## Probar la cámara

```
pip install -r requirements.txt
python ptz_gui.py
```

Rangos medidos en la Link 2: pan −145 a 145, tilt −90 a 100, zoom 100 a 400.
Cerrar Insta360 Link Controller mientras se prueba.

## Raspberry Pi (`pi/`)

| Archivo | Qué hace |
|---|---|
| `autostudio.py` | Arranca todo: cámara, web (puerto 8000) y bot si hay token |
| `camara.py` | Único dueño de la Link 2: vista previa 480p, fotos 4K, video 1080p H.264, PTZ por ioctl, posiciones |
| `web.py` + `static/index.html` | Página para celular: menús Cámara / Base / Luces, vista previa, flechas, zoom, posiciones, galería, video con base y Cancelar |
| `esp32.py` | Habla con el ESP32 por `/dev/ttyUSB0` (luces y base); se reconecta solo |
| `rodaje.py` | Video coordinado con la base: Quieta, Vuelta 360, Paradas, Vaivén; cancelar y volver a 0° |
| `bot.py` | Bot de Telegram: foto, foto vertical, video, encuadre con flechas, posiciones, estado |
| `autostudio.service` | Servicio de systemd (arranque automático) |
| `red-respaldo.*` | Si la Pi quedó en su red propia sin nadie conectado, vuelve a buscar redes conocidas |
| `red.py` | Modo presentación (toggle de la web): fija la red propia `AutoStudio360` |
| `static/portal.html` + `dnsmasq-autostudio.conf` | Portal cautivo de bienvenida en la red propia |

Cómo entrar:

- En la red de casa: `http://192.168.50.15`
- Red propia `AutoStudio360` (5 GHz, clave `12345678`, de prueba): `http://10.42.0.1`. Aparece sola si no hay red conocida o con el toggle **Presentación** de la web; al conectarse sale un portal de bienvenida
- SSH: `ssh shieru@192.168.50.15`

Secretos en la Pi, fuera del repositorio: `~/.config/autostudio/secretos.env` con `TELEGRAM_TOKEN` y `ALLOWED_CHATS`.

Actualizar el código en la Pi:

```
scp pi/*.py shieru@192.168.50.15:autostudio/ && scp pi/static/index.html shieru@192.168.50.15:autostudio/static/
ssh shieru@192.168.50.15 "sudo systemctl restart autostudio"
```
