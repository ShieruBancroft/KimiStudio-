"""Dueño único de la Insta360 Link 2 en la Raspberry Pi (Linux, v4l2).

Un solo proceso abre la cámara y reparte: la vista previa (MJPEG 720p, liviana para el WiFi),
las fotos (se pausa la vista previa y se toma un cuadro en 4K) y el video (H.264 que entrega
la cámara, sin recodificar).
La web y el bot de Telegram le piden todo a esta clase, así nunca se pelean por el USB.
"""
import fcntl
import json
import os
import re
import shutil
import struct
import subprocess
import threading
import time
from datetime import datetime

# v4l2 expresa pan y tilt en arcosegundos (3600 = 1°); la interfaz trabaja en grados como ptz.py.
ARCSEC = 3600
PTZ_CTRL = {"Pan": "pan_absolute", "Tilt": "tilt_absolute", "Zoom": "zoom_absolute"}
# El PTZ va por ioctl directo al driver: abrir v4l2-ctl en cada movimiento costaba ~100 ms en la Pi 3.
CTRL_ID = {"Pan": 0x009A0908, "Tilt": 0x009A0909, "Zoom": 0x009A090D}
VIDIOC_G_CTRL, VIDIOC_S_CTRL = 0xC008561B, 0xC008561C  # struct v4l2_control {u32 id; s32 value}

SOI, EOI = b"\xff\xd8", b"\xff\xd9"
PREVIEW = "1280x720"
# La cámara manda cada cuadro 720p con ~230 KB; recomprimido a 480p queda en ~11 KB (≈1 Mbps a 12 fps),
# lo que cabe holgado en la red propia de la Pi. Cuesta ~85 % de un núcleo de la Pi 3.
PREVIEW_FILTRO = ["-vf", "fps=12,scale=854:480", "-q:v", "5"]
# Formatos de foto que ofrece la Link 2 en MJPEG (todos a 30 fps).
FORMATOS = {"horizontal": "3840x2160", "vertical": "2176x3840", "1080p": "1920x1080"}
CUADROS_FOTO = 15  # ~0,5 s a 30 fps para que la exposición y el foco se asienten tras cambiar de resolución
# Modo vertical: el trípode gira la cámara 90° para que quepan las figuras altas y la imagen se gira
# 90° en sentido horario (queda 9:16). Vista previa y fotos se giran con ffmpeg; el video solo lleva
# la marca de giro en el MP4 (sin recodificar). Se probó recortar a 4:5 y la imagen quedaba chica.
VERTICAL = 90
FILTRO_VERTICAL = "transpose=1"


def buscar_dispositivo(nombre="Insta360"):
    salida = subprocess.run(["v4l2-ctl", "--list-devices"], capture_output=True, text=True).stdout
    bloque = None
    for linea in salida.splitlines():
        if not linea.startswith("\t"):
            bloque = linea
        elif bloque and nombre.lower() in bloque.lower():
            return linea.strip()  # el primer /dev/videoN del bloque es el de video
    return None


class Camara:
    def __init__(self, carpeta, ruta_presets, nombre="Insta360", fps_preview=24):
        # La cámara puede no estar conectada al arrancar o desconectarse después: la web y el portal
        # siguen funcionando y la cámara se reconecta sola en cuanto aparece.
        self.nombre = nombre
        self.dev = None
        self._fd = None
        self.carpeta = carpeta
        self.ruta_presets = ruta_presets
        self.ruta_ajustes = os.path.join(os.path.dirname(ruta_presets), "ajustes.json")
        self.giro = self._leer_ajustes().get("giro", 0)
        os.makedirs(carpeta, exist_ok=True)
        self.fps_preview = fps_preview
        self.ranges = {"Pan": (-145, 145, 0), "Tilt": (-90, 100, 0), "Zoom": (100, 400, 100)}  # los de la Link 2
        self.objetivo = {"Pan": 0, "Tilt": 0, "Zoom": 100}  # a dónde va la cámara; los deltas se suman aquí
        self._centrar_al_despertar = False
        self._conectar()

        self.frame = None          # último JPEG completo de la vista previa
        self.frame_id = 0
        self._cond = threading.Condition()
        self._proc = None
        self._uso = threading.Lock()   # una sola captura (foto o video) a la vez
        self.ocupado = None            # None, "foto" o "video": mientras tanto no hay vista previa
        self.grabando_hasta = None
        self._grab = None              # ffmpeg de la grabación en curso, para poder cancelarla
        self._cancelado = False
        self.retardo = 1.0             # s entre pedir un video y su primer cuadro; se ajusta solo

        self._pending = {}
        self._plock = threading.Lock()
        self._pevent = threading.Event()
        threading.Thread(target=self._ptz_worker, daemon=True).start()
        threading.Thread(target=self._preview_loop, daemon=True).start()

    def _conectar(self):
        dev = buscar_dispositivo(self.nombre)
        if not dev:
            return False
        self.dev = dev
        self.ranges = self._leer_rangos() or self.ranges
        self._fd = os.open(self.dev, os.O_RDWR | os.O_NONBLOCK)  # solo controles; no toma el stream
        self.objetivo = self.get_all()
        # Al prender, la Link 2 está en modo privacidad (mirando abajo) y reporta esa posición; al
        # despertar sube sola sin avisar. Con el primer cuadro se centra para que coincidan.
        self._centrar_al_despertar = True
        print(f"Cámara conectada en {self.dev}", flush=True)
        return True

    def _desconectar(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        self._fd = None
        self.dev = None
        print("Cámara desconectada", flush=True)

    # ---------- PTZ ----------
    def _leer_rangos(self):
        salida = subprocess.run(["v4l2-ctl", "-d", self.dev, "-L"], capture_output=True, text=True).stdout
        rangos = {}
        for eje, ctrl in PTZ_CTRL.items():
            m = re.search(rf"{ctrl} .*?min=(-?\d+) max=(-?\d+)", salida)
            if m:
                lo, hi = int(m.group(1)), int(m.group(2))
                if eje != "Zoom":
                    lo, hi = lo // ARCSEC, hi // ARCSEC
                rangos[eje] = (lo, hi, 0 if eje != "Zoom" else lo)
        return rangos

    def clamp(self, eje, valor):
        lo, hi, _ = self.ranges[eje]
        return max(lo, min(hi, int(round(valor))))

    def set(self, eje, valor):
        eje = eje.capitalize()
        if eje not in self.ranges:
            return
        with self._plock:
            self.objetivo[eje] = self._pending[eje] = self.clamp(eje, valor)
        self._pevent.set()

    def set_many(self, **valores):
        for eje, valor in valores.items():
            self.set(eje, valor)

    def mover(self, **deltas):
        # Las flechas (web y bot) hablan de la pantalla: con la cámara de lado, "derecha" en la imagen
        # girada es otro eje del gimbal.
        x, y = deltas.pop("pan", 0), deltas.pop("tilt", 0)
        pan, tilt = (-y, x) if self.giro == VERTICAL else (x, y)
        if pan:
            deltas["pan"] = pan
        if tilt:
            deltas["tilt"] = tilt
        self.set_many(**{e: self.objetivo[e.capitalize()] + d for e, d in deltas.items()})

    # ---------- Orientación ----------
    def _leer_ajustes(self):
        try:
            with open(self.ruta_ajustes, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def set_giro(self, grados):
        grados = int(grados) % 360
        if grados not in (0, VERTICAL):
            raise RuntimeError("La orientación tiene que ser horizontal (0) o vertical (90)")
        if self.ocupado:
            raise RuntimeError("Espera a que termine la captura en curso")
        self.giro = grados
        ajustes = self._leer_ajustes()
        ajustes["giro"] = grados
        with open(self.ruta_ajustes, "w", encoding="utf-8") as f:
            json.dump(ajustes, f, indent=2)
        self._parar_preview()  # el bucle la vuelve a abrir con el filtro nuevo
        return grados

    def _ioctl(self, pedido, eje, valor=0):
        datos = fcntl.ioctl(self._fd, pedido, struct.pack("Ii", CTRL_ID[eje], valor))
        return struct.unpack("Ii", datos)[1]

    def get_all(self):
        if self._fd is None:
            return dict(self.objetivo)
        res = {}
        try:
            for eje in self.ranges:
                v = self._ioctl(VIDIOC_G_CTRL, eje)
                res[eje] = v if eje == "Zoom" else round(v / ARCSEC)
        except OSError:
            return dict(self.objetivo)
        return res

    def home(self):
        self.set_many(pan=0, tilt=0, zoom=self.ranges["Zoom"][0])

    # Mismo formato que presets.json de Windows: {"1": {"Pan": .., "Tilt": .., "Zoom": ..}}
    def presets(self):
        try:
            with open(self.ruta_presets, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def guardar_preset(self, slot):
        datos = self.presets()
        datos[str(slot)] = self.get_all()
        with open(self.ruta_presets, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2)
        return datos[str(slot)]

    def ir_preset(self, slot):
        p = self.presets().get(str(slot))
        if not p:
            raise RuntimeError(f"El preset {slot} está vacío")
        self.set_many(**{e: v for e, v in p.items() if e in self.ranges})
        return p

    def _ptz_worker(self):
        # Igual que ptz.py: siempre se manda el valor más reciente, sin encolar comandos.
        while True:
            self._pevent.wait()
            with self._plock:
                lote, self._pending = self._pending, {}
                self._pevent.clear()
            for eje, v in lote.items():
                if self._fd is None:
                    break
                try:
                    self._ioctl(VIDIOC_S_CTRL, eje, v if eje == "Zoom" else v * ARCSEC)
                except OSError:
                    pass  # la cámara rechaza valores mientras aún se mueve; el siguiente lote corrige
            time.sleep(0.02)

    # ---------- Vista previa ----------
    def _abrir_mjpeg(self, resolucion, fps, cuadros=None, salida=("-c", "copy")):
        extra = ["-frames:v", str(cuadros)] if cuadros else []
        return subprocess.Popen(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "v4l2", "-input_format", "mjpeg",
             "-video_size", resolucion, "-framerate", str(fps), "-i", self.dev,
             *salida, *extra, "-f", "mjpeg", "pipe:1"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)

    @staticmethod
    def _cuadros(proc):
        # Los cuadros MJPEG van pegados; se cortan por los marcadores de inicio y fin.
        buf = b""
        while True:
            chunk = proc.stdout.read(65536)
            if not chunk:
                return
            buf += chunk
            while True:
                ini = buf.find(SOI)
                fin = buf.find(EOI, ini + 2) if ini >= 0 else -1
                if fin < 0:
                    if ini > 0:
                        buf = buf[ini:]
                    break
                yield buf[ini:fin + 2]
                buf = buf[fin + 2:]

    def _preview_loop(self):
        while True:
            if self.ocupado:
                time.sleep(0.1)
                continue
            if not self.dev and not self._conectar():
                time.sleep(2)
                continue
            filtro = PREVIEW_FILTRO
            if self.giro:
                filtro = ["-vf", PREVIEW_FILTRO[1] + "," + FILTRO_VERTICAL, *PREVIEW_FILTRO[2:]]
            self._proc = self._abrir_mjpeg(PREVIEW, self.fps_preview, salida=filtro)
            if self.ocupado:  # una captura empezó justo mientras arrancaba
                self._parar_preview()
            for frame in self._cuadros(self._proc):
                if self._centrar_al_despertar:
                    self._centrar_al_despertar = False
                    self.home()
                    threading.Timer(3, self.home).start()  # por si lo rechazó mientras aún subía
                with self._cond:
                    self.frame = frame
                    self.frame_id += 1
                    self._cond.notify_all()
            self._proc.wait()
            self._proc = None
            with self._cond:
                self.frame = None
            if not self.ocupado:
                if not os.path.exists(self.dev):
                    self._desconectar()
                time.sleep(1)  # la cámara se desconectó o ffmpeg falló: reintentar

    def esperar_frame(self, ultimo_id, timeout=2.0):
        with self._cond:
            self._cond.wait_for(lambda: self.frame_id != ultimo_id and self.frame, timeout)
            return self.frame_id, self.frame

    def _parar_preview(self):
        p = self._proc
        if p:
            p.terminate()
            try:
                p.wait(3)
            except subprocess.TimeoutExpired:
                p.kill()

    # ---------- Captura ----------
    def _ruta(self, ext):
        return os.path.join(self.carpeta, datetime.now().strftime(f"%Y%m%d_%H%M%S.{ext}"))

    def _tomar(self, modo):
        if not self.dev:
            raise RuntimeError("La cámara no está conectada")
        if not self._uso.acquire(blocking=False):
            raise RuntimeError("La cámara está ocupada con otra captura")
        self.ocupado = modo
        self._parar_preview()

    def _soltar(self):
        self.ocupado = None
        self.grabando_hasta = None
        self._uso.release()

    def foto(self, formato="horizontal"):
        resolucion = FORMATOS.get(formato)
        if not resolucion:
            raise RuntimeError(f"Formato desconocido: {formato}")
        if self.giro and formato == "vertical":
            # Es el recorte vertical de la propia cámara: con el trípode girado saldría acostado.
            raise RuntimeError("En orientación vertical usa 4K o 1080p")
        self._tomar("foto")
        try:
            proc = self._abrir_mjpeg(resolucion, 30, CUADROS_FOTO)
            frame = None
            for frame in self._cuadros(proc):
                pass  # nos quedamos con el último: ya con exposición y foco estables
            proc.wait()
            if not frame:
                raise RuntimeError("La cámara no entregó la foto")
            ruta = self._ruta("jpg")
            if self.giro:
                # Recomprimir un 4K en la Pi 3 tarda ~1-2 s; con -q:v 2 casi no se nota la pérdida.
                giro = subprocess.run(
                    ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "mjpeg", "-i", "pipe:0",
                     "-vf", FILTRO_VERTICAL, "-q:v", "2", "-frames:v", "1", "-update", "1", ruta],
                    input=frame, capture_output=True, timeout=60)
                if giro.returncode != 0 or not os.path.exists(ruta) or os.path.getsize(ruta) == 0:
                    raise RuntimeError("No se pudo girar la foto")
            else:
                with open(ruta, "wb") as f:
                    f.write(frame)
            threading.Thread(target=self.miniatura, args=(os.path.basename(ruta),), daemon=True).start()
            return ruta
        finally:
            self._soltar()

    def grabar(self, segundos, al_empezar=None):
        """Graba H.264 tal como lo entrega la cámara. `al_empezar(t)` recibe la hora del primer cuadro
        (para mover la base a tiempo). Devuelve la ruta, o None si se canceló: el archivo a medias se borra."""
        segundos = max(1, min(60, int(segundos)))
        pedido = time.time()
        self._cancelado = False
        self._tomar("video")
        ruta = self._ruta("mp4")
        try:
            self.grabando_hasta = time.time() + segundos
            # -progress informa cada 0,1 s cuánto video lleva escrito: así se sabe cuándo empezó de verdad.
            # -display_rotation va en sentido antihorario; solo marca el MP4, no recodifica.
            rotar = ["-display_rotation:v:0", str(-self.giro)] if self.giro else []
            proc = self._grab = subprocess.Popen(
                ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostats", "-y", *rotar, "-f", "v4l2", "-input_format", "h264",
                 "-video_size", "1920x1080", "-framerate", "30", "-i", self.dev, "-t", str(segundos),
                 "-c", "copy", "-movflags", "+faststart", "-progress", "pipe:1", "-stats_period", "0.1", ruta],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            if self._cancelado:  # lo cancelaron mientras se apagaba la vista previa
                proc.terminate()
            reloj = threading.Timer(segundos + 20, proc.kill)
            reloj.start()
            inicio = None
            for linea in proc.stdout:
                if inicio is None and linea.startswith("out_time_us="):
                    us = linea.strip().split("=", 1)[1]
                    if us.isdigit() and int(us) > 0:
                        inicio = time.time() - int(us) / 1e6
                        self.grabando_hasta = inicio + segundos
                        self.retardo = 0.7 * self.retardo + 0.3 * (inicio - pedido)
                        if al_empezar:
                            threading.Thread(target=al_empezar, args=(inicio,), daemon=True).start()
            proc.wait()
            reloj.cancel()
            if self._cancelado:
                if os.path.exists(ruta):
                    os.remove(ruta)
                return None
            if not os.path.exists(ruta) or os.path.getsize(ruta) == 0:
                raise RuntimeError("La grabación falló")
            threading.Thread(target=self.miniatura, args=(os.path.basename(ruta),), daemon=True).start()
            return ruta
        finally:
            self._grab = None
            self._soltar()

    def cancelar_video(self):
        """Corta la grabación en curso; grabar() borra el archivo a medias."""
        if self.ocupado != "video":
            return False
        self._cancelado = True
        if self._grab:
            self._grab.terminate()
        return True

    def version_liviana(self, ruta, max_mb=48):
        """Copia de 720p para Telegram (límite de 50 MB por archivo) usando el codificador por hardware."""
        if os.path.getsize(ruta) <= max_mb * 1024 * 1024:
            return ruta
        salida = ruta.replace(".mp4", "_tg.mp4")
        subprocess.run(
            # La cámara graba en yuvj420p y el codificador por hardware solo acepta yuv420p.
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", ruta, "-vf",
             # ffmpeg ya endereza el video girado al leerlo: se escala sin deformar, sea horizontal o vertical.
             "scale=1280:1280:force_original_aspect_ratio=decrease:force_divisible_by=2,format=yuv420p",
             "-c:v", "h264_v4l2m2m", "-b:v", "5M", "-an", "-movflags", "+faststart", salida],
            capture_output=True, timeout=600)
        if not os.path.exists(salida) or os.path.getsize(salida) == 0:
            raise RuntimeError("No se pudo preparar el video para Telegram; el original quedó en la galería")
        return salida

    def necesita_conversion(self, ruta, max_mb=48):
        return os.path.getsize(ruta) > max_mb * 1024 * 1024

    # ---------- Estado ----------
    def estado(self):
        temp = subprocess.run(["vcgencmd", "measure_temp"], capture_output=True, text=True).stdout
        disco = shutil.disk_usage(self.carpeta)
        return {
            "camara": bool(self.dev),
            "grabando": bool(self.grabando_hasta),
            "ocupado": self.ocupado,
            "restante": max(0, round(self.grabando_hasta - time.time())) if self.grabando_hasta else 0,
            "vista_previa": self.frame is not None,
            "ptz": self.get_all(),
            "rangos": self.ranges,
            "giro": self.giro,
            "temp": temp.strip().replace("temp=", "").replace("'C", " °C"),
            "libre_gb": round(disco.free / 1024 ** 3, 1),
        }

    def miniatura(self, nombre):
        """JPEG de ~480 px para la galería: una foto 4K pesa ~700 KB, su miniatura ~20 KB."""
        nombre = os.path.basename(nombre)
        origen = os.path.join(self.carpeta, nombre)
        carpeta = os.path.join(self.carpeta, ".miniaturas")
        destino = os.path.join(carpeta, os.path.splitext(nombre)[0] + ".jpg")
        if not os.path.exists(destino) and os.path.exists(origen):
            os.makedirs(carpeta, exist_ok=True)
            entrada = ["-ss", "0.5", "-i", origen] if nombre.endswith(".mp4") else ["-i", origen]
            subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *entrada, "-frames:v", "1",
                            "-vf", "scale=480:480:force_original_aspect_ratio=decrease", "-q:v", "5", destino],
                           capture_output=True, timeout=30)
        return destino

    def galeria(self):
        archivos = [a for a in os.listdir(self.carpeta)
                    if a.endswith((".jpg", ".mp4")) and not a.endswith("_tg.mp4")]
        archivos.sort(reverse=True)
        return [{"nombre": a, "tipo": "video" if a.endswith(".mp4") else "foto",
                 "mb": round(os.path.getsize(os.path.join(self.carpeta, a)) / 1024 ** 2, 1)}
                for a in archivos]
