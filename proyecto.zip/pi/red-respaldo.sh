#!/bin/sh
# Si la Pi quedó en su propia red (AutoStudio360) y nadie está conectado, la apaga un momento
# para que NetworkManager vuelva a buscar las redes conocidas (casa u hotspot de un celular).
# Si no encuentra ninguna, NetworkManager vuelve a levantar AutoStudio360 solo.
# Lo ejecuta red-respaldo.timer cada 3 minutos.

# En modo presentación la red propia se queda fija (lo activa el toggle de la web).
[ -f /home/shieru/.config/autostudio/modo_presentacion ] && exit 0

activa=$(nmcli -t -f NAME con show --active | grep -x autostudio-ap)
[ -z "$activa" ] && exit 0

clientes=$(/usr/sbin/iw dev wlan0 station dump 2>/dev/null | grep -c '^Station')
[ "$clientes" -gt 0 ] && exit 0

nmcli con down autostudio-ap >/dev/null 2>&1
