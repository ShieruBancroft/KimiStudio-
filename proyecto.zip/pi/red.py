"""Modo presentación: fija la red propia AutoStudio360 aunque haya WiFi conocido.

La Pi 3B+ tiene un solo radio WiFi: o se conecta a una red (hay internet y Telegram)
o crea AutoStudio360 (cualquiera se conecta directo, sin internet). Este módulo cambia
entre los dos y deja la elección guardada para los reinicios.
"""
import os
import subprocess
import threading
import time

AP = "autostudio-ap"
BANDERA = os.path.expanduser("~/.config/autostudio/modo_presentacion")  # la lee red-respaldo.sh
PRIORIDAD_ON, PRIORIDAD_OFF = 100, -10  # con 100 gana a cualquier red conocida también al arrancar
IP_AP = "10.42.0.1"


def _nmcli(*args):
    return subprocess.run(["sudo", "-n", "nmcli", *args], capture_output=True, text=True, timeout=60)


def presentacion_activa():
    return os.path.exists(BANDERA)


def red_actual():
    salida = subprocess.run(["nmcli", "-t", "-f", "NAME,DEVICE", "con", "show", "--active"],
                            capture_output=True, text=True).stdout
    for linea in salida.splitlines():
        nombre, _, dispositivo = linea.rpartition(":")
        if dispositivo == "wlan0":
            return nombre
    return None


def _aplicar(activar):
    time.sleep(2)  # que alcance a llegar la respuesta al navegador antes de cortar el WiFi
    _nmcli("con", "modify", AP, "connection.autoconnect-priority", str(PRIORIDAD_ON if activar else PRIORIDAD_OFF))
    if activar:
        _nmcli("con", "up", AP)
    else:
        _nmcli("con", "down", AP)  # NetworkManager vuelve a la mejor red conocida; si no hay, levanta el AP


def cambiar(activar):
    if activar:
        os.makedirs(os.path.dirname(BANDERA), exist_ok=True)
        open(BANDERA, "w").close()
    elif os.path.exists(BANDERA):
        os.remove(BANDERA)
    threading.Thread(target=_aplicar, args=(activar,), daemon=True).start()


def ip_casa():
    """Última IP de la Pi en una red normal: la página la usa para volver sola al salir del modo presentación."""
    guardada = os.path.expanduser("~/.config/autostudio/ip_casa")
    if red_actual() not in (None, AP):
        salida = subprocess.run(["ip", "-4", "-o", "addr", "show", "wlan0"], capture_output=True, text=True).stdout
        partes = salida.split()
        if "inet" in partes:
            ip = partes[partes.index("inet") + 1].split("/")[0]
            with open(guardada, "w") as f:
                f.write(ip)
            return ip
    try:
        with open(guardada) as f:
            return f.read().strip()
    except OSError:
        return None


def estado():
    return {"presentacion": presentacion_activa(), "red": red_actual(), "ip_ap": IP_AP, "ip_casa": ip_casa()}
