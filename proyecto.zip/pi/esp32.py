"""Conexión por USB con el ESP32 (firmware AutoStudio360 v2.0): luces en 2 zonas y base giratoria.

El ESP32 aparece como /dev/ttyUSB0 (chip CH340). Si no está conectado, la web y el bot siguen
funcionando y el módulo lo vuelve a buscar solo cada pocos segundos.
Protocolo: una línea por comando; las respuestas empiezan por OK, DONE, ERR, STATUS, INFO, PONG o READY.
"""
import glob
import os
import queue
import re
import threading
import time

try:
    import serial
except ImportError:  # sin pyserial la web arranca igual, con el ESP32 como "desconectado"
    serial = None

BAUDIOS = 115200
RE_ESTADO = re.compile(r"ang=([-\d.]+) mov=(\d)")
RE_ZONA = re.compile(r"Z(\d)=([\d.]+)%/([\d.]+)K")
RE_PARAM = re.compile(r"vel=([\d.]+) acc=([\d.]+)")


class ESP32:
    def __init__(self, puerto=None):
        self.puerto_fijo = puerto or os.environ.get("AUTOSTUDIO_ESP32")
        self.puerto = None
        self.ser = None
        self.lineas = queue.Queue()
        self._cmd = threading.Lock()   # un comando a la vez
        self._ultimo = {}              # último STATUS leído
        threading.Thread(target=self._vigilar, daemon=True).start()

    @property
    def conectado(self):
        return self.ser is not None

    # ---------- Conexión ----------
    def _candidatos(self):
        if self.puerto_fijo:
            return [self.puerto_fijo]
        return sorted(glob.glob("/dev/ttyUSB*")) + sorted(glob.glob("/dev/ttyACM*"))

    def _vigilar(self):
        while True:
            if self.ser is None and serial is not None:
                for p in self._candidatos():
                    if self._abrir(p):
                        break
            time.sleep(3)

    def _abrir(self, puerto):
        try:
            ser = serial.Serial(puerto, BAUDIOS, timeout=0.2)
        except (OSError, serial.SerialException):
            return False
        time.sleep(2)  # abrir el puerto reinicia el ESP32; esperar a que arranque
        ser.reset_input_buffer()
        try:
            ser.write(b"PING\n")
            fin = time.time() + 2
            while time.time() < fin:
                if ser.readline().decode(errors="ignore").strip() == "PONG":
                    break
            else:
                ser.close()  # otro aparato serie o un ESP32 sin nuestro firmware
                return False
        except (OSError, serial.SerialException):
            ser.close()
            return False
        self.ser, self.puerto = ser, puerto
        print(f"ESP32 conectado en {puerto}", flush=True)
        threading.Thread(target=self._leer, args=(ser,), daemon=True).start()
        return True

    def _leer(self, ser):
        try:
            while True:
                linea = ser.readline().decode(errors="ignore").strip()
                if linea:
                    self.lineas.put(linea)
        except (OSError, serial.SerialException, TypeError):
            pass
        self._cerrar()

    def _cerrar(self):
        ser, self.ser = self.ser, None
        if ser is not None:
            print("ESP32 desconectado", flush=True)
            try:
                ser.close()
            except Exception:
                pass

    # ---------- Comandos ----------
    def enviar(self, comando, espera=("OK", "ERR"), timeout=2.0):
        """Manda una línea y devuelve la primera respuesta que empiece por algo de `espera`."""
        with self._cmd:
            if self.ser is None:
                raise RuntimeError("ESP32 desconectado")
            while not self.lineas.empty():
                self.lineas.get_nowait()
            try:
                self.ser.write((comando + "\n").encode())
            except (OSError, serial.SerialException):
                self._cerrar()
                raise RuntimeError("ESP32 desconectado")
            fin = time.time() + timeout
            while time.time() < fin:
                try:
                    linea = self.lineas.get(timeout=fin - time.time())
                except queue.Empty:
                    break
                if linea.startswith("ERR"):
                    raise RuntimeError(linea[4:] or "error del ESP32")
                if linea.startswith(espera):
                    return linea
            raise RuntimeError("El ESP32 no respondió")

    def estado(self):
        """Ángulo de la base y brillo/tono de cada zona. Si hay un comando en curso, el último leído."""
        if self.ser is None:
            return {"conectado": False}
        if self._cmd.acquire(blocking=False):
            self._cmd.release()
            try:
                linea = self.enviar("STATUS", espera=("STATUS",), timeout=1.0)
                m = RE_ESTADO.search(linea)
                self._ultimo = {
                    "angulo": float(m.group(1)) if m else None,
                    "girando": bool(m and m.group(2) == "1"),
                    "zonas": {z: {"brillo": round(float(b)), "kelvin": round(float(k))}
                              for z, b, k in RE_ZONA.findall(linea)},
                }
            except RuntimeError:
                pass
        return {"conectado": self.ser is not None, "puerto": self.puerto, **self._ultimo}

    # ---------- Luces ----------
    def luz(self, zona, brillo, kelvin, ms=300):
        """zona 0 = las dos, 1 = adelante (T1+T2), 2 = atrás (T3+T4)."""
        return self.enviar(f"LIGHT {int(zona)} {float(brillo):.0f} {int(kelvin)} {int(ms)}")

    def apagar_luces(self):
        return self.enviar("OFF")

    def probar_luces(self):
        return self.enviar("TEST", espera=("DONE TEST",), timeout=10)

    # ---------- Base ----------
    def base(self, accion, valor=None):
        acciones = {
            "rot": lambda: f"ROT {float(valor):.1f}",
            "goto": lambda: f"GOTO {float(valor):.1f}",
            "turn": lambda: f"TURN {float(valor):.1f}",
            "spin": lambda: f"SPIN {float(valor):.1f}",
            "speed": lambda: f"SPEED {float(valor):.1f}",
            "stop": lambda: "STOP",
            "zero": lambda: "ZERO",
        }
        if accion not in acciones:
            raise RuntimeError("acción desconocida")
        espera = ("DONE",) if accion == "zero" else ("OK",)
        return self.enviar(acciones[accion](), espera=espera)

    def girando(self):
        m = RE_ESTADO.search(self.enviar("STATUS", espera=("STATUS",), timeout=1.0))
        return bool(m and m.group(2) == "1")

    def parametros(self):
        """Velocidad (°/s) y aceleración (°/s²) actuales, para dejarlas como estaban después de un video."""
        m = RE_PARAM.search(self.enviar("STATUS", espera=("STATUS",), timeout=1.0))
        return (float(m.group(1)), float(m.group(2))) if m else (30.0, 45.0)
