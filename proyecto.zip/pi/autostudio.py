"""Servicio principal de AutoStudio 360 en la Raspberry Pi: cámara + web + bot de Telegram.

Secretos en ~/.config/autostudio/secretos.env (fuera del repositorio):
    TELEGRAM_TOKEN=...
    ALLOWED_CHATS=123456789,987654321
Sin TELEGRAM_TOKEN arranca solo la web.
"""
import os
import threading

from werkzeug.serving import make_server

from bot import Bot
from camara import Camara
from esp32 import ESP32
from web import crear_app

CARPETA = os.environ.get("AUTOSTUDIO_MEDIA", os.path.expanduser("~/autostudio-media"))
# 80 permite abrir http://autostudio.lan sin escribir puerto; 8000 se mantiene por compatibilidad.
PUERTOS = [int(x) for x in os.environ.get("AUTOSTUDIO_PORTS", "80,8000").split(",")]
PRESETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "presets.json")


def main():
    cam = Camara(CARPETA, PRESETS)
    print(f"Cámara: {cam.dev or 'no conectada (se reconecta sola)'}, archivos en {CARPETA}", flush=True)

    token = os.environ.get("TELEGRAM_TOKEN")
    if token:
        permitidos = {int(x) for x in os.environ.get("ALLOWED_CHATS", "").split(",") if x.strip()}
        Bot(cam, token, permitidos).iniciar()
        print(f"Bot de Telegram activo para {len(permitidos)} chat(s)", flush=True)

    esp = ESP32()  # lo busca solo en /dev/ttyUSB* y se reconecta si se desenchufa
    app = crear_app(cam, esp)
    servidores = []
    for puerto in PUERTOS:
        try:
            servidores.append(make_server("0.0.0.0", puerto, app, threaded=True))
            print(f"Web en el puerto {puerto}", flush=True)
        except OSError as e:  # p. ej. el 80 sin permiso fuera del servicio de systemd
            print(f"No se pudo abrir el puerto {puerto}: {e}", flush=True)
    for srv in servidores[1:]:
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    servidores[0].serve_forever()


if __name__ == "__main__":
    main()
