"""Video con la base giratoria: coordina la grabación de la cámara con los movimientos del plato.

Modos:
- quieta:  la base no se mueve.
- vuelta:  una vuelta exacta a velocidad constante. El motor arranca antes del primer cuadro y frena
           después del último, así el video no tiene rampas y el final empalma con el principio (bucle).
- paradas: frente, lado, atrás y lado; gira 90° y se detiene, 4 veces.
- vaiven:  0° → +45° → −45° → 0°, despacio y frenando en cada extremo.
Todos empiezan y terminan de frente (0°). Al terminar o cancelar, la base vuelve a 0° con la
velocidad y aceleración que tenía antes.
"""
import math
import threading
import time

MODOS = {"quieta": "Quieta", "vuelta": "Vuelta 360", "paradas": "Paradas", "vaiven": "Vaivén"}
VEL_MAX = 60.0       # °/s, el mismo límite del firmware (VEL_MAX_GS)
ACEL_VUELTA = 90.0   # °/s²: con esto la rampa de arranque dura menos de medio segundo
ACEL_PARADA = 120.0
MARGEN = 0.3         # s a velocidad constante antes del primer cuadro
PAUSA_MIN = 0.3      # s quieto como mínimo en cada lado (paradas)


def tiempo_giro(grados, vel, acel):
    """Duración de un giro con rampa de subida y bajada (perfil trapezoidal del firmware)."""
    if grados < vel * vel / acel:
        return 2 * math.sqrt(grados / acel)
    return grados / vel + vel / acel


def pausa_paradas(segundos):
    return segundos / 4 - tiempo_giro(90, VEL_MAX, ACEL_PARADA)


def validar(modo, segundos):
    if modo not in MODOS:
        raise ValueError("Modo de base desconocido")
    if modo == "vuelta" and 360 / segundos > VEL_MAX:
        raise ValueError(f"Una vuelta en {segundos} s es muy rápida: elige 10 s o más")
    if modo == "paradas" and pausa_paradas(segundos) < PAUSA_MIN:
        raise ValueError(f"Las paradas no caben en {segundos} s: elige 10 s o más")


class Rodaje:
    def __init__(self, cam, esp):
        self.cam, self.esp = cam, esp
        self.modo = None   # nombre del modo mientras dura un video lanzado desde la página
        self.fase = None   # "preparando", "grabando" o "volviendo"
        self.base_ocupada = False  # mientras tanto los botones del menú Base no la mueven
        self._cancelar = threading.Event()

    def empezar(self, segundos, modo="quieta"):
        segundos = max(1, min(60, int(segundos)))
        validar(modo, segundos)
        if self.modo or self.cam.ocupado:
            raise RuntimeError("Ya hay una grabación en curso")
        if not self.cam.dev:
            raise RuntimeError("La cámara no está conectada")
        if modo != "quieta" and (self.esp is None or not self.esp.conectado):
            raise RuntimeError("ESP32 desconectado: elige Quieta o conéctalo")
        self.modo = MODOS[modo]
        self.fase = "preparando"
        self.base_ocupada = modo != "quieta"
        self._cancelar.clear()
        threading.Thread(target=self._correr, args=(segundos, modo), daemon=True).start()

    def cancelar(self):
        if not self.modo and self.cam.ocupado != "video":
            return False
        self._cancelar.set()
        self.cam.cancelar_video()
        return True

    # ---------- Orden de un video ----------
    def _correr(self, segundos, modo):
        previo = None
        try:
            if modo != "quieta":
                previo = self.esp.parametros()
            if modo == "vuelta":
                self._vuelta(segundos)
            elif modo == "paradas":
                self._ir(0)
                self._cmd(f"SPEED {VEL_MAX:.1f}")
                self._cmd(f"ACCEL {ACEL_PARADA:.1f}")
                self._grabar(segundos, self._paradas)
            elif modo == "vaiven":
                self._ir(0)
                self._grabar(segundos, self._vaiven)
            else:
                self._grabar(segundos)
        except Exception as e:  # el video no debe dejar la base girando ni la página bloqueada
            print(f"Video con base ({modo}): {e}", flush=True)
        finally:
            if previo:
                self.fase = "volviendo"
                try:
                    self._cmd("STOP")
                    self._esperar_quieta(10, cortar=False)
                    self._cmd(f"SPEED {previo[0]:.1f}")
                    self._cmd(f"ACCEL {previo[1]:.1f}")
                    self._ir(0, cortar=False)
                except Exception as e:
                    print(f"No se pudo devolver la base a 0°: {e}", flush=True)
            self.modo = self.fase = None
            self.base_ocupada = False

    def _grabar(self, segundos, coreografia=None):
        """Graba y, si hay coreografía, la corre en este hilo desde el primer cuadro."""
        if self._cancelar.is_set():
            return
        self.fase = "grabando"
        empezo, t0, fin = threading.Event(), [], threading.Event()

        def al_empezar(t):
            t0.append(t)
            empezo.set()

        def grabar():
            try:
                self.cam.grabar(segundos, al_empezar=al_empezar)
            finally:
                fin.set()
                empezo.set()

        threading.Thread(target=grabar, daemon=True).start()
        if coreografia:
            empezo.wait(segundos + 20)
            if t0 and not fin.is_set():
                coreografia(t0[0], segundos, fin)
        fin.wait(segundos + 30)

    def _vuelta(self, segundos):
        v, a = 360 / segundos, ACEL_VUELTA
        rampa, giro_rampa = v / a, v * v / (2 * a)
        # El primer cuadro llega `retardo` s después de pedir el video. Se arranca desde atrás para
        # que el plato pase por 0° a velocidad constante justo cuando empieza la grabación.
        espera = max(0.0, rampa + MARGEN - self.cam.retardo)
        self._ir(-(giro_rampa + v * (espera + self.cam.retardo - rampa)))
        if self._cancelar.is_set():
            return
        self._cmd(f"ACCEL {a:.1f}")
        self._cmd(f"SPIN {v:.2f}")
        if self._cancelar.wait(espera):
            return
        self._grabar(segundos)

    def _paradas(self, t0, segundos, fin):
        tramo = segundos / 4
        pausa = tramo - tiempo_giro(90, VEL_MAX, ACEL_PARADA)
        for k in range(4):
            if not self._hasta(t0 + pausa / 2 + k * tramo, fin) or not self._esperar_quieta(3):
                return
            self._cmd("ROT 90")

    def _vaiven(self, t0, segundos, fin):
        inicio = 0.0
        for grados, fraccion in ((45, 0.25), (-90, 0.5), (45, 0.25)):
            tramo = segundos * fraccion
            t = 0.95 * tramo  # holgura para que el último giro termine antes que el video
            if not self._hasta(t0 + inicio, fin) or not self._esperar_quieta(3):
                return
            # Rampas de un tercio del tiempo cada una: arranca y frena suave en cada extremo.
            self._cmd(f"SPEED {min(VEL_MAX, 1.5 * abs(grados) / t):.2f}")
            self._cmd(f"ACCEL {4.5 * abs(grados) / (t * t):.2f}")
            self._cmd(f"ROT {grados}")
            inicio += tramo

    # ---------- Ayudas ----------
    def _cmd(self, linea):
        return self.esp.enviar(linea)

    def _ir(self, grados, cortar=True):
        self._cmd(f"GOTO {grados:.2f}")
        self._esperar_quieta(15, cortar)

    def _hasta(self, t, fin):
        """Espera hasta la hora t. False si cancelaron o la grabación ya terminó."""
        while time.time() < t:
            if self._cancelar.is_set() or fin.is_set():
                return False
            time.sleep(min(0.05, max(0.0, t - time.time())))
        return not (self._cancelar.is_set() or fin.is_set())

    def _esperar_quieta(self, timeout, cortar=True):
        fin = time.time() + timeout
        while time.time() < fin:
            if cortar and self._cancelar.is_set():
                return False
            if not self.esp.girando():
                return True
            time.sleep(0.1)
        return False
