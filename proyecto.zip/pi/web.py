"""Página web de la cabina: vista previa en vivo, PTZ, foto, video y galería.

Se abre desde cualquier aparato en la misma red: http://<ip-de-la-pi> o, en la red propia,
http://autostudio.lan (que además funciona como portal cautivo).
"""
import ipaddress
import os
import subprocess
import threading
import time

from flask import Flask, Response, jsonify, redirect, request, send_from_directory

import red
from rodaje import Rodaje

FPS_WEB = 12  # la vista previa ya llega recomprimida a 480p (~11 KB por cuadro)
NOMBRE = "autostudio.lan"


def es_propio(host):
    """True si el navegador pidió la Pi por IP, por su nombre o por .local; False si pidió otro sitio."""
    host = host.rsplit(":", 1)[0].strip("[]").lower()
    if host in (NOMBRE, "localhost") or host.endswith(".local"):
        return True
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def crear_app(cam, esp=None):
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    rodaje = Rodaje(cam, esp)

    aceptados = set()  # IPs que ya tocaron "Abrir estudio" en el portal

    @app.before_request
    def portal_cautivo():
        # En AutoStudio360 el DNS de la Pi responde cualquier nombre con 10.42.0.1. Cuando el celular
        # prueba si hay internet (connectivitycheck.gstatic.com, captive.apple.com, msftconnecttest.com…)
        # llega aquí con otro nombre; al redirigirlo cree que es la página de inicio del WiFi y la abre sola.
        if es_propio(request.host):
            return None
        if request.remote_addr not in aceptados:
            return redirect(f"http://{NOMBRE}/portal", code=302)
        # Ya aceptó: se responde lo que cada sistema espera para dar la red por "conectada"
        # y que deje de mostrar el aviso de inicio de sesión.
        # Google usa /generate_204 y /gen_204; OnePlus/ColorOS usa /generate204.
        if request.path.rstrip("/").endswith(("generate_204", "generate204", "gen_204")):
            return "", 204
        if "apple" in request.host or request.path == "/hotspot-detect.html":
            return "<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>"
        if request.path == "/connecttest.txt":
            return "Microsoft Connect Test"
        if request.path == "/ncsi.txt":
            return "Microsoft NCSI"
        return redirect(f"http://{NOMBRE}/", code=302)

    @app.get("/portal")
    def portal():
        return send_from_directory(app.static_folder, "portal.html")

    @app.post("/api/portal/aceptar")
    def portal_aceptar():
        aceptados.add(request.remote_addr)
        return jsonify(ok=True)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/stream.mjpg")
    def stream():
        def generar():
            ultimo, pausa = -1, 1 / FPS_WEB
            while True:
                t0 = time.time()
                ultimo, frame = cam.esperar_frame(ultimo)
                if not frame:
                    time.sleep(0.5)  # grabando o sin cámara: el navegador conserva el último cuadro
                    continue
                yield (b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                       + str(len(frame)).encode() + b"\r\n\r\n" + frame + b"\r\n")
                time.sleep(max(0, pausa - (time.time() - t0)))
        return Response(generar(), mimetype="multipart/x-mixed-replace; boundary=frame")

    @app.get("/api/estado")
    def estado():
        return jsonify(**cam.estado(), esp32=bool(esp and esp.conectado),
                       video_base=rodaje.modo, fase=rodaje.fase, base_ocupada=rodaje.base_ocupada)

    @app.post("/api/ptz")
    def ptz():
        datos = request.get_json(force=True)
        if datos.get("home"):
            cam.home()
        elif "delta" in datos:
            cam.mover(**datos["delta"])
        else:
            cam.set_many(**{k: v for k, v in datos.items() if k in ("pan", "tilt", "zoom")})
        return jsonify(ok=True)

    @app.post("/api/giro")
    def giro():
        if rodaje.modo:
            return jsonify(ok=False, error="Espera a que termine el video"), 409
        try:
            return jsonify(ok=True, giro=cam.set_giro(request.get_json(force=True).get("grados", 0)))
        except (RuntimeError, ValueError, TypeError) as e:
            return jsonify(ok=False, error=str(e)), 409

    @app.get("/api/red")
    def red_estado():
        return jsonify(red.estado())

    @app.post("/api/red")
    def red_cambiar():
        red.cambiar(bool(request.get_json(force=True).get("presentacion")))
        return jsonify(ok=True, **red.estado())

    @app.post("/api/apagar")
    def apagar():
        # Desenchufar la Pi encendida daña archivos de la SD (pasó con index.html y camara.py);
        # este botón la apaga en orden para que se pueda desconectar sin comandos.
        if cam.ocupado or rodaje.modo:
            return jsonify(ok=False, error="Espera a que termine la captura en curso"), 409

        def _apagar():
            time.sleep(2)  # que alcance a llegar la respuesta al navegador
            subprocess.run(["sudo", "-n", "systemctl", "poweroff"])
        threading.Thread(target=_apagar, daemon=True).start()
        return jsonify(ok=True)

    @app.get("/api/presets")
    def presets():
        return jsonify(cam.presets())

    @app.post("/api/presets/<int:slot>")
    def preset(slot):
        try:
            if request.get_json(force=True).get("accion") == "guardar":
                return jsonify(ok=True, preset=cam.guardar_preset(slot))
            return jsonify(ok=True, preset=cam.ir_preset(slot))
        except RuntimeError as e:
            return jsonify(ok=False, error=str(e)), 404

    @app.post("/api/foto")
    def foto():
        try:
            formato = request.get_json(force=True).get("formato", "horizontal")
            return jsonify(ok=True, archivo=os.path.basename(cam.foto(formato)))
        except RuntimeError as e:
            return jsonify(ok=False, error=str(e)), 409

    @app.post("/api/grabar")
    def grabar():
        d = request.get_json(force=True)
        try:
            segundos = int(d.get("segundos", 10))
            rodaje.empezar(segundos, d.get("base", "quieta"))
        except (RuntimeError, ValueError, TypeError) as e:
            return jsonify(ok=False, error=str(e)), 409
        return jsonify(ok=True, segundos=segundos)

    @app.post("/api/grabar/cancelar")
    def grabar_cancelar():
        if not rodaje.cancelar():
            return jsonify(ok=False, error="No hay ninguna grabación en curso"), 409
        return jsonify(ok=True)

    # ---------- ESP32: luces y base giratoria ----------
    @app.get("/api/esp32")
    def esp32_estado():
        return jsonify(esp.estado() if esp else {"conectado": False})

    def _esp32(accion):
        if esp is None or not esp.conectado:
            return jsonify(ok=False, error="ESP32 desconectado"), 503
        try:
            accion()
            return jsonify(ok=True)
        except (RuntimeError, ValueError, TypeError) as e:
            return jsonify(ok=False, error=str(e)), 409

    @app.post("/api/luces")
    def luces():
        d = request.get_json(force=True)
        if d.get("apagar"):
            return _esp32(esp.apagar_luces)
        if d.get("probar"):
            return _esp32(esp.probar_luces)
        # "zonas": [{zona, brillo, kelvin}, ...] para las escenas que fijan adelante y atrás a la vez
        zonas = d.get("zonas") or [d]
        return _esp32(lambda: [esp.luz(z["zona"], z["brillo"], z["kelvin"], d.get("ms", 300)) for z in zonas])

    @app.post("/api/base")
    def base():
        d = request.get_json(force=True)
        if rodaje.base_ocupada:
            return jsonify(ok=False, error="La base está ocupada con el video"), 409
        return _esp32(lambda: esp.base(d.get("accion"), d.get("valor")))

    @app.get("/api/galeria")
    def galeria():
        return jsonify(cam.galeria())

    @app.get("/media/<path:nombre>")
    def media(nombre):
        return send_from_directory(cam.carpeta, nombre, as_attachment=request.args.get("descargar") == "1")

    @app.get("/miniatura/<path:nombre>")
    def miniatura(nombre):
        ruta = cam.miniatura(nombre)
        if not os.path.exists(ruta):
            return "", 404
        return send_from_directory(os.path.dirname(ruta), os.path.basename(ruta), max_age=86400)

    @app.delete("/media/<path:nombre>")
    def borrar(nombre):
        nombre = os.path.basename(nombre)
        for ruta in (os.path.join(cam.carpeta, nombre),
                     os.path.join(cam.carpeta, ".miniaturas", os.path.splitext(nombre)[0] + ".jpg"),
                     os.path.join(cam.carpeta, nombre.replace(".mp4", "_tg.mp4"))):
            if os.path.exists(ruta):
                os.remove(ruta)
        return jsonify(ok=True)

    return app
