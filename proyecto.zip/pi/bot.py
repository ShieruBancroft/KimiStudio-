"""Bot de Telegram de la cabina. Solo obedece a los chats de ALLOWED_CHATS.

Comandos: /foto [vertical], /video [segundos], /camara (encuadre con flechas), /posicion [1-5],
/estado, /centro.
"""
import json
import os
import threading
import time

import requests

PASO = 15       # grados por toque de flecha
PASO_ZOOM = 50

TECLADO_MENU = {"keyboard": [["📸 Foto", "📱 Foto vertical"], ["🎬 Video 10 s", "🎯 Encuadre"],
                             ["📍 Posiciones", "📊 Estado"]],
                "resize_keyboard": True}

TECLADO_PTZ = {"inline_keyboard": [
    [{"text": "⬆️", "callback_data": "tilt:+"}],
    [{"text": "⬅️", "callback_data": "pan:-"}, {"text": "🎯", "callback_data": "centro"},
     {"text": "➡️", "callback_data": "pan:+"}],
    [{"text": "⬇️", "callback_data": "tilt:-"}],
    [{"text": "➖ Zoom", "callback_data": "zoom:-"}, {"text": "➕ Zoom", "callback_data": "zoom:+"}],
    [{"text": "📸 Tomar esta foto", "callback_data": "foto"}],
]}


class Bot:
    def __init__(self, cam, token, permitidos):
        self.cam = cam
        self.api = f"https://api.telegram.org/bot{token}/"
        self.permitidos = permitidos

    def llamar(self, metodo, archivos=None, timeout=60, **datos):
        r = requests.post(self.api + metodo, data=datos, files=archivos, timeout=timeout)
        return r.json()

    def enviar(self, chat, texto, **extra):
        if "reply_markup" in extra:
            extra["reply_markup"] = json.dumps(extra["reply_markup"])
        return self.llamar("sendMessage", chat_id=chat, text=texto, **extra)

    def iniciar(self):
        threading.Thread(target=self._bucle, daemon=True).start()

    def _bucle(self):
        offset = 0
        while True:
            try:
                r = requests.get(self.api + "getUpdates",
                                 params={"offset": offset, "timeout": 50}, timeout=60).json()
            except requests.RequestException:
                time.sleep(5)  # sin internet: se reintenta
                continue
            for u in r.get("result", []):
                offset = u["update_id"] + 1
                # Cada pedido en su hilo: grabar un video no debe congelar el bot.
                threading.Thread(target=self._atender, args=(u,), daemon=True).start()

    def _atender(self, u):
        try:
            if "message" in u:
                self._mensaje(u["message"])
            elif "callback_query" in u:
                self._boton(u["callback_query"])
        except Exception as e:  # noqa: BLE001 — un error nunca debe tumbar el bot
            chat = (u.get("message") or u.get("callback_query", {}).get("message", {})).get("chat", {}).get("id")
            if chat in self.permitidos:
                self.enviar(chat, f"⚠️ {e}")

    def _mensaje(self, m):
        chat, texto = m["chat"]["id"], (m.get("text") or "").strip()
        if chat not in self.permitidos:
            self.enviar(chat, f"Este bot es privado. Tu ID es {chat}.")
            return
        cmd = texto.split()[0].lower() if texto else ""
        if cmd in ("/start", "/menu"):
            self.enviar(chat, "AutoStudio 360 listo. ¿Qué hacemos?", reply_markup=TECLADO_MENU)
        elif cmd == "/foto" or texto in ("📸 Foto", "📱 Foto vertical"):
            self._foto(chat, "vertical" if "vertical" in texto.lower() else "horizontal")
        elif cmd == "/posicion" or texto == "📍 Posiciones":
            partes = texto.split()
            if len(partes) > 1 and partes[1].isdigit():
                self._posicion(chat, partes[1])
            else:
                self._menu_posiciones(chat)
        elif cmd == "/video" or texto.startswith("🎬"):
            partes = texto.split()
            segundos = int(partes[1]) if len(partes) > 1 and partes[1].isdigit() else 10
            self._video(chat, segundos)
        elif cmd == "/camara" or texto == "🎯 Encuadre":
            self._encuadre(chat)
        elif cmd == "/estado" or texto == "📊 Estado":
            e = self.cam.estado()
            p = e["ptz"]
            self.enviar(chat, f"🌡 {e['temp']}\n💾 {e['libre_gb']} GB libres\n"
                              f"🎥 {'no conectada' if not e['camara'] else 'grabando' if e['grabando'] else 'lista'}\n"
                              f"↔️ pan {p['Pan']}°  ↕️ tilt {p['Tilt']}°  🔍 zoom {p['Zoom']}")
        elif cmd == "/centro":
            self.cam.home()
            self.enviar(chat, "🎯 Cámara al centro")
        else:
            self.enviar(chat, "Comandos: /foto, /foto vertical, /video 10, /camara, /posicion 3, /estado, /centro",
                        reply_markup=TECLADO_MENU)

    def _menu_posiciones(self, chat):
        guardados = self.cam.presets()
        fila = [{"text": n if n in guardados else f"{n} (vacío)", "callback_data": f"preset:{n}"}
                for n in ("1", "2", "3", "4", "5")]
        self.enviar(chat, "¿A qué posición voy?", reply_markup={"inline_keyboard": [fila[:3], fila[3:]]})

    def _posicion(self, chat, slot):
        p = self.cam.ir_preset(slot)
        self.enviar(chat, f"📍 Posición {slot}: pan {p['Pan']}°, tilt {p['Tilt']}°, zoom {p['Zoom']}")

    def _foto(self, chat, formato="horizontal"):
        self.llamar("sendChatAction", chat_id=chat, action="upload_photo")
        ruta = self.cam.foto(formato)
        with open(ruta, "rb") as f:
            self.llamar("sendPhoto", archivos={"photo": f}, chat_id=chat)
        with open(ruta, "rb") as f:  # original sin compresión de Telegram
            self.llamar("sendDocument", archivos={"document": f}, chat_id=chat, timeout=120)

    def _video(self, chat, segundos):
        self.enviar(chat, f"🎬 Grabando {segundos} s…")
        self.llamar("sendChatAction", chat_id=chat, action="record_video")
        ruta = self.cam.grabar(segundos)
        if ruta is None:
            self.enviar(chat, "Video cancelado desde la página.")
            return
        if self.cam.necesita_conversion(ruta):
            self.enviar(chat, f"⏳ Preparando el video para Telegram (unos {segundos * 3} s)…")
        self.llamar("sendChatAction", chat_id=chat, action="upload_video")
        envio = self.cam.version_liviana(ruta)
        with open(envio, "rb") as f:
            self.llamar("sendVideo", archivos={"video": f}, chat_id=chat, supports_streaming="true",
                        caption=os.path.basename(ruta), timeout=300)

    def _encuadre(self, chat):
        _, frame = self.cam.esperar_frame(-1, timeout=5)
        self.llamar("sendPhoto", archivos={"photo": ("vista.jpg", frame)}, chat_id=chat,
                    caption="Encuadre", reply_markup=json.dumps(TECLADO_PTZ))

    def _boton(self, q):
        chat, msg = q["message"]["chat"]["id"], q["message"]["message_id"]
        if chat not in self.permitidos:
            return
        accion = q["data"]
        self.llamar("answerCallbackQuery", callback_query_id=q["id"])
        if accion == "foto":
            self._foto(chat)
            return
        if accion.startswith("preset:"):
            self._posicion(chat, accion.split(":")[1])
            return
        if accion == "centro":
            self.cam.home()
        else:
            eje, signo = accion.split(":")
            paso = PASO_ZOOM if eje == "zoom" else PASO
            self.cam.mover(**{eje: paso if signo == "+" else -paso})
        time.sleep(1.2)  # la cámara tarda en llegar y reenfocar
        ultimo, _ = self.cam.esperar_frame(-1)
        _, frame = self.cam.esperar_frame(ultimo)
        p = self.cam.get_all()
        media = {"type": "photo", "media": "attach://vista",
                 "caption": f"Encuadre · pan {p['Pan']}° · tilt {p['Tilt']}° · zoom {p['Zoom']}"}
        self.llamar("editMessageMedia", archivos={"vista": ("vista.jpg", frame)}, chat_id=chat,
                    message_id=msg, media=json.dumps(media), reply_markup=json.dumps(TECLADO_PTZ))
