"""Control PTZ de la Insta360 Link 2 vía DirectShow (UVC estándar).

Módulo reutilizable: lo usa la GUI de prueba y luego lo usará el puente hacia Unity.
"""
import threading
import time

import duvc_ctl as d

AXES = ("Pan", "Tilt", "Zoom", "Roll")


class PTZCamera:
    def __init__(self, name_contains="Insta360"):
        devices = d.list_devices()
        matches = [(i, x) for i, x in enumerate(devices) if name_contains.lower() in x.name.lower()]
        if not matches:
            raise RuntimeError(f"No se encontró una cámara que contenga '{name_contains}'")
        self.index, self.device = matches[0]  # índice DirectShow, sirve también para OpenCV (CAP_DSHOW)
        self.name = self.device.name
        self.ranges = {}
        for axis in AXES:
            ok, r = d.get_camera_property_range(self.device, getattr(d.CamProp, axis))
            if ok:
                self.ranges[axis] = (r.min, r.max, r.default_val)

        # Las escrituras van por un hilo que siempre manda el valor más reciente,
        # así mover un slider rápido no encola cientos de comandos USB.
        self._pending = {}
        self._lock = threading.Lock()
        self._event = threading.Event()
        threading.Thread(target=self._worker, daemon=True).start()

    def clamp(self, axis, value):
        lo, hi, _ = self.ranges[axis]
        return max(lo, min(hi, int(round(value))))

    def set(self, axis, value):
        if axis not in self.ranges:
            return
        with self._lock:
            self._pending[axis] = self.clamp(axis, value)
        self._event.set()

    def set_many(self, **values):
        for axis, value in values.items():
            self.set(axis.capitalize(), value)

    def get(self, axis):
        ok, s = d.get_camera_property(self.device, getattr(d.CamProp, axis))
        return s.value if ok else None

    def get_all(self):
        return {axis: self.get(axis) for axis in self.ranges}

    def home(self):
        self.set_many(pan=0, tilt=0, zoom=self.ranges["Zoom"][0])

    def _worker(self):
        while True:
            self._event.wait()
            with self._lock:
                batch, self._pending = self._pending, {}
                self._event.clear()
            for axis, value in batch.items():
                d.set_camera_property(self.device, getattr(d.CamProp, axis),
                                      d.PropSetting(value, d.CamMode.Manual))
            time.sleep(0.02)
