// =====================================================================
//  AutoStudio 360 — FIRMWARE UNICO DEL ESP32: base giratoria + luces
//  v2.0 · octubre 2026
//
//  Un solo ESP32 (30 pines, en su placa de bornera) conectado por USB a
//  la Raspberry Pi. Maneja:
//    - 4 modulos MOSFET D4184 en 2 ZONAS de luz (adelante y atras),
//      cada zona con canal FRIO y canal CALIDO (cinta COB CCT 12 V).
//    - 1 driver TMC2208 + motor NEMA17 con el plato acoplado directo (1:1).
//    - Sensor Hall opcional para el cero del plato (HOME).
//
//  Placa en el Arduino IDE: "ESP32 Dev Module"
//  Nucleo esp32 de Espressif: 3.1 o superior
//  Libreria: FastAccelStepper (gin66)  -> Herramientas > Gestionar librerias
//  Monitor serie: 115200 baudios, "Nueva linea" (Newline)
//
//  PINES (nombres de la placa de bornera: D18 = GPIO18, etc.)
//    Luces  zona 1 (ADELANTE, torres T1 y T2): D18 frio · D19 calido
//    Luces  zona 2 (ATRAS,    torres T3 y T4): D23 frio · D32 calido
//    Motor  TMC2208: D25 EN · D26 STEP · D27 DIR
//    Hall   (opcional): D33
//
//  COMANDOS DE LUCES
//    LIGHT <zona> <brillo> [kelvin] [ms]
//        zona  : 1 = adelante, 2 = atras, 0 = las dos
//        brillo: 0 a 100 (%)
//        kelvin: 2700 (calido) a 6500 (frio). Si no se pone, deja el tono
//        ms    : transicion en milisegundos (300 por defecto)
//      Ejemplos: LIGHT 0 80 5000 -> todo al 80 %, luz neutra
//                LIGHT 2 50 2700 -> zona de atras al 50 %, calida
//                LIGHT 1 0       -> apaga la zona de adelante
//    OFF                 apaga las dos zonas
//    TEST                prende cada zona 1 s en FRIO y 1 s en CALIDO
//
//  COMANDOS DE LA BASE
//    ROT <grados>        gira relativo (+ horario, - antihorario)
//    GOTO <grados>       va a un angulo absoluto 0-360 por el camino corto
//    TURN <seg> [1|-1]   una vuelta completa en ese tiempo (video)
//    SPIN <grados/s>     giro continuo hasta STOP
//    STOP / ESTOP        frenar suave / frenar en seco
//    ZERO                el angulo actual pasa a ser 0
//    HOME                busca el cero con el sensor Hall
//    SPEED <g/s>         velocidad para ROT/GOTO (30 por defecto)
//    ACCEL <g/s2>        aceleracion (45 por defecto)
//    MOTOR 0|1           0 = soltar el plato, 1 = sujetarlo
//    INVERT              invierte el sentido de giro (queda guardado)
//    MREV <n>            n vueltas exactas del eje del motor (prueba)
//    SETGEAR <zm> <zp>   solo si algun dia ponen engranajes (1:1 por defecto)
//
//  COMUNES
//    STATUS              angulo, movimiento y estado de las dos zonas
//    INFO                version, relacion de engranajes, pines
//    PING                responde PONG
//
//  Toda respuesta empieza por OK, DONE, ERR, STATUS, INFO, PONG o READY.
// =====================================================================
#include <FastAccelStepper.h>
#include <Preferences.h>

// ------------------------- LUCES -------------------------------------
const int     NUM_ZONAS = 2;
const uint8_t PIN_FRIO[NUM_ZONAS]   = {18, 23};   // zona 1, zona 2
const uint8_t PIN_CALIDO[NUM_ZONAS] = {19, 32};

const uint32_t PWM_HZ   = 19531;    // alto: la camara no ve parpadeo
const uint8_t  PWM_BITS = 12;       // 4096 niveles
const float    PWM_MAX  = (1 << PWM_BITS) - 1;
const float    K_CALIDO = 2700.0f;  // lo que diga la cinta
const float    K_FRIO   = 6500.0f;
const float    BRILLO_MAX = 100.0f; // bajar (ej. 80) si las cintas calientan

struct Zona {
  float b = 0, k = 5000;      // brillo y tono actuales
  float b0 = 0, k0 = 5000;    // al empezar la transicion
  float b1 = 0, k1 = 5000;    // destino
  uint32_t t0 = 0, dur = 0;   // transicion en curso
};
Zona zona[NUM_ZONAS];

// ------------------------- BASE --------------------------------------
const uint8_t PIN_STEP = 26;
const uint8_t PIN_DIR  = 27;
const uint8_t PIN_EN   = 25;    // activo en BAJO
const uint8_t PIN_HOME = 33;    // sensor Hall A3144: LOW con el iman

const int32_t PASOS_MOTOR = 200;    // NEMA17 = 1,8 grados por paso
const int32_t MICROPASOS  = 16;     // MS1 y MS2 del TMC2208 en 3V3
const int32_t PASOS_VUELTA_MOTOR = PASOS_MOTOR * MICROPASOS;   // 3200
const float   VEL_MAX_GS = 60.0f;   // limite de seguridad (grados/s)

FastAccelStepperEngine engine;
FastAccelStepper *motor = nullptr;
Preferences prefs;
int     dientesMotor = 1, dientesPlato = 1;
int32_t PASOS_VUELTA = PASOS_VUELTA_MOTOR;
float   PASOS_GRADO  = PASOS_VUELTA / 360.0f;
bool    invertir = false;
float   velGS = 30.0f, accelGS = 45.0f;
String  opPendiente = "";

char buf[64]; uint8_t nbuf = 0;

// ========================= LUCES =====================================
// El tono se mezcla en escala "mired" (1.000.000 / K), que es como el ojo
// percibe la temperatura de color. El brillo lleva gamma 2.2 para que
// 50 % se vea como "la mitad".
void escribirZona(int i, float brillo, float kelvin) {
  kelvin = constrain(kelvin, K_CALIDO, K_FRIO);
  float m = 1e6f / kelvin, mc = 1e6f / K_FRIO, mw = 1e6f / K_CALIDO;
  float fracFrio = (mw - m) / (mw - mc);
  float nivel = powf(constrain(brillo, 0.0f, BRILLO_MAX) / 100.0f, 2.2f);
  ledcWrite(PIN_FRIO[i],   (uint32_t)(nivel * fracFrio * PWM_MAX + 0.5f));
  ledcWrite(PIN_CALIDO[i], (uint32_t)(nivel * (1.0f - fracFrio) * PWM_MAX + 0.5f));
}

void programarZona(int i, float b, float k, uint32_t ms) {
  Zona &z = zona[i];
  z.b0 = z.b; z.k0 = z.k; z.b1 = b; z.k1 = k; z.t0 = millis(); z.dur = ms;
  if (ms == 0) { z.b = b; z.k = k; escribirZona(i, b, k); }
}

void actualizarZonas() {
  for (int i = 0; i < NUM_ZONAS; i++) {
    Zona &z = zona[i];
    if (z.dur == 0) continue;
    float x = (millis() - z.t0) / (float)z.dur;
    if (x >= 1.0f) { x = 1.0f; z.dur = 0; }
    z.b = z.b0 + (z.b1 - z.b0) * x;
    z.k = z.k0 + (z.k1 - z.k0) * x;
    escribirZona(i, z.b, z.k);
  }
}

void pruebaCableado() {
  // Cada zona: 1 s solo FRIO, 1 s solo CALIDO. Si prende otra zona u otro
  // color, ese cable esta cruzado.
  for (int i = 0; i < NUM_ZONAS; i++) programarZona(i, 0, 5000, 0);
  for (int i = 0; i < NUM_ZONAS; i++) {
    Serial.printf("TEST zona %d: FRIO\n", i + 1);
    programarZona(i, 60, K_FRIO, 0);   delay(1200);
    Serial.printf("TEST zona %d: CALIDO\n", i + 1);
    programarZona(i, 60, K_CALIDO, 0); delay(1200);
    programarZona(i, 0, 5000, 0);      delay(300);
  }
  Serial.println("DONE TEST");
}

// ========================= BASE ======================================
void recalcular() {
  PASOS_VUELTA = lroundf((float)PASOS_VUELTA_MOTOR * dientesPlato / dientesMotor);
  PASOS_GRADO  = PASOS_VUELTA / 360.0f;
}
int32_t gradosAPasos(float g) { return (int32_t)lroundf(g * PASOS_GRADO); }
int32_t dirPasos(int32_t p)   { return invertir ? -p : p; }

float anguloActual() {
  int32_t p = motor->getCurrentPosition();
  if (invertir) p = -p;
  p %= PASOS_VUELTA; if (p < 0) p += PASOS_VUELTA;
  return p / PASOS_GRADO;
}

void normalizar() {
  if (motor->isRunning()) return;
  int32_t p = motor->getCurrentPosition() % PASOS_VUELTA;
  if (p < 0) p += PASOS_VUELTA;
  motor->setCurrentPosition(p);
}

void aplicarVelocidad(float gs, float acc) {
  gs = constrain(fabsf(gs), 0.5f, VEL_MAX_GS);
  motor->setSpeedInHz((uint32_t)max(1L, lroundf(gs * PASOS_GRADO)));
  motor->setAcceleration((int32_t)max(1L, lroundf(acc * PASOS_GRADO)));
}

void ok(const char *c)  { Serial.printf("OK %s\n", c); }
void err(const char *m) { Serial.printf("ERR %s\n", m); }

void mover(const char *op, int32_t pasos) {
  motor->enableOutputs();
  if (motor->move(dirPasos(pasos)) != MOVE_OK) { err("MOVE rechazado"); return; }
  opPendiente = op; ok(op);
}

void buscarHome() {
  aplicarVelocidad(15, 30);
  motor->enableOutputs();
  if (invertir) motor->runBackward(); else motor->runForward();
  uint32_t t0 = millis();
  while (digitalRead(PIN_HOME) == HIGH) {
    if (millis() - t0 > 30000) {
      motor->forceStop(); err("HOME no encontrado");
      aplicarVelocidad(velGS, accelGS); return;
    }
    delay(1);
  }
  motor->forceStop();
  while (motor->isRunning()) delay(1);
  motor->setCurrentPosition(0);
  aplicarVelocidad(velGS, accelGS);
  Serial.println("DONE HOME pos=0.00");
}

// ========================= COMANDOS ==================================
void mostrarEstado() {
  Serial.printf("STATUS ang=%.2f mov=%d vel=%.1f acc=%.1f",
                anguloActual(), motor->isRunning(), velGS, accelGS);
  for (int i = 0; i < NUM_ZONAS; i++)
    Serial.printf(" Z%d=%.0f%%/%.0fK", i + 1, zona[i].b, zona[i].k);
  Serial.println();
}

void procesar(char *linea) {
  for (char *p = linea; *p; p++) *p = toupper(*p);
  char cmd[12] = ""; float a = NAN, b = NAN, c = NAN, d = NAN;
  int n = sscanf(linea, "%11s %f %f %f %f", cmd, &a, &b, &c, &d);
  if (n < 1) return;
  String s(cmd);
  bool ocupado = motor->isRunning();

  // ---- comunes ----
  if (s == "PING")   { Serial.println("PONG"); return; }
  if (s == "STATUS") { mostrarEstado(); return; }
  if (s == "INFO") {
    Serial.printf("INFO fw=AutoStudio360-2.0 engranajes=%d:%d pasos_vuelta=%ld invertido=%d zonas=%d\n",
                  dientesMotor, dientesPlato, (long)PASOS_VUELTA, invertir, NUM_ZONAS);
    return;
  }

  // ---- luces ----
  if (s == "TEST") { pruebaCableado(); return; }
  if (s == "OFF") {
    for (int i = 0; i < NUM_ZONAS; i++) programarZona(i, 0, zona[i].k, 300);
    ok("OFF"); return;
  }
  if (s == "LIGHT") {
    if (n < 3) return err("uso: LIGHT <zona 0-2> <brillo 0-100> [kelvin] [ms]");
    int z = (int)a;
    if (z < 0 || z > NUM_ZONAS) return err("zona debe ser 0 (todas), 1 o 2");
    uint32_t ms = (n >= 5) ? (uint32_t)max(0.0f, d) : 300;
    for (int i = 0; i < NUM_ZONAS; i++) {
      if (z != 0 && i != z - 1) continue;
      float k = (n >= 4) ? c : zona[i].k;
      programarZona(i, constrain(b, 0.0f, 100.0f), constrain(k, K_CALIDO, K_FRIO), ms);
    }
    ok("LIGHT"); return;
  }

  // ---- base ----
  if (s == "ROT") {
    if (n < 2) return err("uso: ROT <grados>");
    if (ocupado) return err("OCUPADO");
    aplicarVelocidad(velGS, accelGS); mover("ROT", gradosAPasos(a)); return;
  }
  if (s == "GOTO") {
    if (n < 2) return err("uso: GOTO <grados>");
    if (ocupado) return err("OCUPADO");
    normalizar();
    int32_t actual = motor->getCurrentPosition(); if (invertir) actual = -actual;
    actual = ((actual % PASOS_VUELTA) + PASOS_VUELTA) % PASOS_VUELTA;
    int32_t objetivo = gradosAPasos(fmodf(fmodf(a, 360.0f) + 360.0f, 360.0f));
    int32_t dd = objetivo - actual;
    if (dd >  PASOS_VUELTA / 2) dd -= PASOS_VUELTA;
    if (dd < -PASOS_VUELTA / 2) dd += PASOS_VUELTA;
    aplicarVelocidad(velGS, accelGS); mover("GOTO", dd); return;
  }
  if (s == "TURN") {
    if (n < 2 || a <= 0) return err("uso: TURN <segundos> [1|-1]");
    if (ocupado) return err("OCUPADO");
    float gs = 360.0f / a;
    aplicarVelocidad(gs, max(accelGS, gs * 2.0f));
    mover("TURN", ((n >= 3 && b < 0) ? -1 : 1) * PASOS_VUELTA); return;
  }
  if (s == "SPIN") {
    if (n < 2 || a == 0) return err("uso: SPIN <grados_por_segundo>");
    aplicarVelocidad(a, accelGS); motor->enableOutputs();
    if ((a > 0) != invertir) motor->runForward(); else motor->runBackward();
    opPendiente = ""; ok("SPIN"); return;
  }
  if (s == "STOP")  { motor->stopMove();  opPendiente = "STOP"; ok("STOP");  return; }
  if (s == "ESTOP") { motor->forceStop(); opPendiente = "STOP"; ok("ESTOP"); return; }
  if (s == "ZERO")  { if (ocupado) return err("OCUPADO"); motor->setCurrentPosition(0);
                      Serial.println("DONE ZERO pos=0.00"); return; }
  if (s == "HOME")  { if (ocupado) return err("OCUPADO"); buscarHome(); return; }
  if (s == "SPEED") { if (n < 2 || a <= 0) return err("uso: SPEED <grados/s>");
                      velGS = constrain(a, 0.5f, VEL_MAX_GS); ok("SPEED"); return; }
  if (s == "ACCEL") { if (n < 2 || a <= 0) return err("uso: ACCEL <grados/s2>");
                      accelGS = a; ok("ACCEL"); return; }
  if (s == "MOTOR") {
    if (n >= 2 && a == 0) { if (ocupado) return err("OCUPADO"); motor->disableOutputs(); }
    else motor->enableOutputs();
    ok("MOTOR"); return;
  }
  if (s == "INVERT") {
    if (ocupado) return err("OCUPADO");
    invertir = !invertir; prefs.putBool("inv", invertir); ok("INVERT"); return;
  }
  if (s == "SETGEAR") {
    if (n < 3 || a < 1 || b < 1) return err("uso: SETGEAR <dientes_motor> <dientes_plato>");
    if (ocupado) return err("OCUPADO");
    dientesMotor = (int)a; dientesPlato = (int)b;
    prefs.putInt("zm", dientesMotor); prefs.putInt("zp", dientesPlato);
    recalcular(); motor->setCurrentPosition(0);
    Serial.printf("DONE SETGEAR %d:%d pasos_vuelta=%ld\n", dientesMotor, dientesPlato, (long)PASOS_VUELTA);
    return;
  }
  if (s == "MREV") {
    if (n < 2 || a == 0) return err("uso: MREV <vueltas_del_motor>");
    if (ocupado) return err("OCUPADO");
    motor->setSpeedInHz(800); motor->setAcceleration(1600);
    mover("MREV", lroundf(a * PASOS_VUELTA_MOTOR)); return;
  }
  err("comando desconocido");
}

// =====================================================================
void setup() {
  Serial.begin(115200);

  // Luces: arrancan apagadas
  for (int i = 0; i < NUM_ZONAS; i++) {
    ledcAttach(PIN_FRIO[i],   PWM_HZ, PWM_BITS);
    ledcAttach(PIN_CALIDO[i], PWM_HZ, PWM_BITS);
    escribirZona(i, 0, 5000);
  }

  // Base
  pinMode(PIN_HOME, INPUT_PULLUP);
  prefs.begin("base", false);
  dientesMotor = prefs.getInt("zm", 1);
  dientesPlato = prefs.getInt("zp", 1);
  invertir     = prefs.getBool("inv", false);
  recalcular();
  engine.init();
  motor = engine.stepperConnectToPin(PIN_STEP);
  if (!motor) { while (true) { Serial.println("ERR pin STEP"); delay(1000); } }
  motor->setDirectionPin(PIN_DIR);
  motor->setEnablePin(PIN_EN, true);
  motor->setAutoEnable(false);
  motor->enableOutputs();
  aplicarVelocidad(velGS, accelGS);

  Serial.printf("READY AutoStudio360 engranajes=%d:%d zonas=%d\n", dientesMotor, dientesPlato, NUM_ZONAS);
}

void loop() {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\r') continue;
    if (ch == '\n') { buf[nbuf] = 0; if (nbuf) procesar(buf); nbuf = 0; }
    else if (nbuf < sizeof(buf) - 1) buf[nbuf++] = ch;
  }
  actualizarZonas();
  if (opPendiente.length() && !motor->isRunning()) {
    if (opPendiente != "MREV") normalizar();
    Serial.printf("DONE %s pos=%.2f\n", opPendiente.c_str(), anguloActual());
    opPendiente = "";
  }
}
