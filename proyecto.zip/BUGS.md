# Bugs · AutoStudio 360

## Abiertos

- **Android marca `AutoStudio360` como "sin internet" y resuelve nombres por datos móviles.** `autostudio.lan` no carga en Chrome; el portal usa `http://10.42.0.1`. No tiene arreglo sin internet real en la Pi (el chequeo HTTPS de Android no se puede simular).

- **Bajo voltaje en la Pi** (11 oct): `Undervoltage detected` varias veces en 17 min, `get_throttled=0x50000`, y arranques con "orphan cleanup" (apagados sin cerrar el sistema). El usuario dice que usa la fuente original. Es la causa probable de los archivos dañados de abajo. Mitigación: botón Apagar en la web; falta revisar fuente/cable. 25 oct: `0x50000` tras 39 min en la mañana; `0x0` en el arranque de la tarde con el ESP32 en su USB. 30 oct: `0x0` tras 33 min con ESP32 y motor.

## Cerrados (2026-11-08)

| Síntoma | Causa | Corrección | Prueba |
|---|---|---|---|
| Windows dice "el PIN no es correcto" al conectarse a `AutoStudio360` con `12345678` | Windows pide primero el PIN WPS del router y la Pi no tiene WPS | Tocar "Conectarse con una clave de seguridad", o guardar la red con `netsh wlan add profile` y la clave | PC conectado, página 200 en `10.42.0.1` |

## Cerrados (2026-10-30)

| Síntoma | Causa | Corrección | Prueba |
|---|---|---|---|
| `ROT 90` respondía `DONE` pero el motor solo zumbaba; con el driver activo el plato giraba libre a mano | Contacto flojo del conector del motor en la protoboard (bobinas sin corriente). Bobinas rojo+azul y verde+negro correctas; VM, VIO, EN y Vref (1,12 V) correctos | Conector retirado y vuelto a clavar en a5–a8 | Salto del eje al conectar 12 V; `ROT 90`, `TURN`, `SPIN` y 3 vueltas con ~450 g en la marca |
| Escenas de luz desordenadas y difíciles de tocar en el celular | Puntos sobre la barra de tono, alternados arriba/abajo | Fila de 4 botones alineados con su temperatura | Playwright 390 y 1200 px: misma altura, Contraluz manda 85 %/4300 K + 100 %/6500 K |

## Cerrados (2026-10-25)

| Síntoma | Causa | Corrección | Prueba |
|---|---|---|---|
| Recién prendida la Pi, el primer toque de cualquier flecha bajaba la cámara hasta abajo | Al prender, la Link 2 está en modo privacidad (mirando abajo) y la Pi guarda esa posición; luego la cámara sube sola y los deltas se suman a la posición vieja | `camara.py` centra la cámara (pan 0, tilt 0, zoom mínimo) con el primer cuadro de video, y repite a los 3 s | Arranque completo de la Pi: queda en 0/0/100 |
| T1 y T2 nunca quedaban del todo cálidas (más blancas que T3/T4 a 2700 K) | Estaño uniendo los contactos C y W de una cinta de adelante: los dos canales de la zona 1 quedaban conectados | El usuario separó la soldadura | Las 4 torres iguales en cálido puro y en frío puro |
| `arduino-cli upload`: "Wrong boot mode detected (0x13)" | La placa CH340C no entra sola en modo de carga ni se reinicia sola al terminar | Mantener BOOT durante "Connecting…"; presionar EN después | Firmware subido, `PONG` |

## Cerrados (2026-10-11)

| Síntoma | Causa | Corrección | Prueba |
|---|---|---|---|
| La página mostraba la imagen pero se quedaba en "conectando…"; ni foto, ni video, ni PTZ (en AP y en el router) | `index.html` en la Pi dañado: línea suelta `texto" : "Modo presentación desactivado",` → error de sintaxis, no corría el JS. `camara.py` también era una versión vieja mezclada con basura | Se subieron todos los archivos de `pi/` del repo y se reinició el servicio; md5 Pi = repo | Edge headless: estado, posiciones y galería cargan; foto 1080p por la API OK |

## Cerrados (2026-09-26)

| Síntoma | Causa | Corrección | Prueba |
|---|---|---|---|
| La Pi no arrancaba, quedó en "emergency mode" | Se desconectó durante el primer arranque (la expansión de la partición tarda >3 min en esa SD) | Se completó el usuario a mano; no desconectar en el primer arranque | Arranque limpio, `systemctl --failed` vacío |
| WiFi "No network with SSID found" | El SSID real es `Kasproduction corp ` (espacio al final) | Conexión con el nombre exacto | `nmcli` conecta, IP 192.168.50.15 |
| Tras reiniciar cambió la contraseña y apareció una conexión WiFi duplicada | cloud-init del Imager corrió tarde | Borrada la conexión duplicada, `/etc/cloud/cloud-init.disabled` | Reinicio posterior sin cambios |
| Video para Telegram vacío (`Invalid argument`) | La cámara graba en `yuvj420p` y `h264_v4l2m2m` solo acepta `yuv420p` | `format=yuv420p` en el filtro | 15 s: 72 MB → 9 MB, enviado a Telegram |
| Toda la página dejó de responder (toggle, foto, flechas) | Un `\n` del generador quedó como salto de línea real dentro de un string JS | Modal propio en vez de `confirm()`; `node --check` del JS antes de subir | Prueba con Playwright sin errores |
| El OnePlus seguía pidiendo "Iniciar sesión" tras aceptar | Su chequeo usa `/generate204` (sin guion bajo) | Se responde 204 a `generate_204`, `generate204` y `gen_204` | curl simulado: 302 antes, 204 después |
| Sin página ni portal tras reiniciar | El servicio se caía en bucle si la cámara no estaba conectada | `camara.py` arranca sin cámara y la reconecta sola; la web avisa "Cámara desconectada" | Servicio activo y portal 302 sin cámara |
| Voltaje bajo (`0x50005`), cámara sin detectar | Fuente de alimentación insuficiente | Fuente nueva | `get_throttled=0x0` |
| Vista previa lenta en la red propia | Cuadros MJPEG 720p de ~230 KB (~15 Mbps) | Recompresión a 480p (~11 KB, ~1 Mbps) y AP en 5 GHz | 36 cuadros en 3 s a 11 KB |
