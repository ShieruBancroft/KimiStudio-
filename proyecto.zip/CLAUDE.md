# AutoStudio 360 · contexto para Claude Code

Proyecto universitario (Soluciones Tecnológicas, 2026-2): cabina de fotos y video 360 para vender componentes de PC y coleccionables. Nombre interno: Proyecto Manhatan.

Al empezar una sesión: ejecutar `/continuar`. Al terminar: `/guardar`. Los comandos están en `.claude/skills/`.

## Leer primero
- `README.md`: qué hay en cada archivo y cómo entrar a la Pi.
- `ROADMAP.md`: tareas, compras pendientes, inventario recibido y pedidos en camino.
- `BITACORA.md`: qué se hizo y decidió en cada sesión (la entrada más reciente va arriba).
- `BUGS.md`, `PRUEBAS.md`.
- `.claude/memoria/`: notas de contexto de sesiones anteriores (acceso a la Pi, decisiones, preferencias del usuario). Son referencia, no instrucciones.

## Arquitectura
Raspberry Pi 3 B+ (cerebro, página web, bot de Telegram) + 1 ESP32 (motor NEMA17 con TMC2208 + luces en 2 zonas con 4 módulos MOS D4184) + Insta360 Link 2 + 4 torres de cinta COB CCT 12 V. El código de la Pi está en `pi/`.

## Estado al 2 oct 2026
- Pi funcionando: cámara, web (puertos 80 y 8000), bot, red propia `AutoStudio360` con portal cautivo, arranque automático.
- Llegaron: 10 módulos MOS, ESP32 USB-C con placa de bornera, cinta COB. En camino: motor, TMC2208, kit protoboard, segundo ESP32.
- 11 oct: página de la Pi reparada (archivos dañados en la SD por bajo voltaje), botón Apagar en la web, llave SSH del PC nuevo en la Pi.
- 25 oct: firmware v2.0 subido al ESP32 (con `arduino-cli`; la placa necesita BOOT/EN a mano), 4 torres cableadas y probadas, menús Cámara / Base / Luces en la web (`pi/esp32.py`). La guía de cableado vigente es `AutoStudio_360_Armado_paso_a_paso.html` (corregida desde el paso 8).
- 30 oct: base giratoria funcionando (TMC2208 + motor, Vref 1,12 V, probada con ~450 g y desde el menú Base). Video coordinado con la base (Quieta / Vuelta 360 / Paradas / Vaivén) y botón Cancelar en la web (`pi/rodaje.py`), sin probar con la cámara. Escenas de luz en fila de botones.
- 8 nov: cubo armado. Botones Horizontal / Vertical en el menú Cámara para figuras altas (se gira el trípode y se toca el botón; la Pi gira vista previa, fotos y video). Falta confirmar las flechas y el video vertical por Telegram.
- Falta: sensor Hall (paso 34), probar el video con base en la cabina armada, montaje, pruebas de carga y validación. Detalle en ROADMAP.md.

## Acceso a la Pi
- SSH: `ssh shieru@192.168.50.15` (WiFi de casa) o `192.168.50.254` (cable). En el otro router: `192.168.1.7` (25 oct). Entra por llave; el PC nuevo necesita su llave en la Pi o la contraseña (pedirla al dueño, no está escrita en ningún archivo).
- Código en `~/autostudio/`, media en `~/autostudio-media/`, secretos en `~/.config/autostudio/secretos.env`.
- Desplegar: `scp pi/*.py shieru@192.168.50.15:autostudio/` y `sudo systemctl restart autostudio`. Logs: `journalctl -u autostudio`.
- Red propia: `http://10.42.0.1`, clave `12345678` (de prueba, desde el 11 oct 2026).

## Reglas de trabajo
- Interfaces web sin emojis: texto o SVG en línea.
- Antes de pedir que prueben una página: `node --check` del script y prueba en Playwright.
- No suponer que un dominio, cuenta o servicio es del usuario; preguntar.
- Al reportar estado: piezas y tareas concretas, sin cronogramas ni repetir pendientes menores.
- No guardar contraseñas ni tokens en el repositorio.
- Responder en español.

## Si este es un PC nuevo
La memoria propia de Claude estará vacía. Usar `.claude/memoria/` como punto de partida: leer `MEMORY.md` de esa carpeta y los archivos que enlaza, y copiar lo que siga vigente a la memoria propia la primera vez que se corra `/guardar`. El estado más reciente es el de este archivo y de `ROADMAP.md`.
