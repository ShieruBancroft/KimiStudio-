# Pruebas · AutoStudio 360

El proyecto no tiene suite automática todavía. Las pruebas son manuales o con scripts sueltos contra la Pi.

## Historial

| Fecha | Prueba | Resultado |
|---|---|---|
| 2026-09-26 | Link 2 en la Pi: formatos, foto, video, PTZ | OK: MJPEG/H.264 hasta 4K; foto 4K en ~3 s; video 1080p ~30 fps; PTZ 12 ms por comando |
| 2026-09-26 | Vista previa en la red propia | 480p a 12 fps, ~11 KB por cuadro, ~85 % de un núcleo |
| 2026-09-26 | Miniaturas de galería | ~14 KB contra 420–700 KB del original |
| 2026-09-26 | Video largo por Telegram | 15 s → 9 MB en 720p, conversión en 44 s, recibido en Telegram |
| 2026-09-26 | Reinicio completo | Servicio, bot y WiFi de casa arrancan solos |
| 2026-09-26 | Modo presentación ida y vuelta | AP activo con prioridad 100; vuelve a casa en ~20 s |
| 2026-09-26 | Portal cautivo (curl simulando Android/iPhone) | 302 a `/portal` antes de aceptar; 204 y "Success" después |
| 2026-09-26 | Página y portal en Edge headless (Playwright) | Sin errores JS; toggle, modal y "Copiar dirección" funcionan |
| 2026-10-02 | Guía de armado: balance de etiquetas, ids duplicados, emojis (script Python) | 0 errores, 0 duplicados, 0 emojis |
| 2026-10-02 | Guía de armado: `node --check` de los 2 scripts en línea | OK |
| 2026-10-02 | Paso a paso: cada paso apunta a un pin existente de la pieza dibujada (Node, sin navegador) | 46 pasos con cable, 0 errores |
| 2026-10-02 | Paso a paso: captura con `msedge --headless=new --screenshot` | Dibujos legibles tras corregir rótulos y rutas de cables |
| 2026-10-02 | Firmware `AutoStudio360.ino` | **Sin compilar**: no hay Arduino IDE en este PC |
| 2026-10-11 | API de la Pi con vista previa abierta (Python, 8 rondas) | `/api/estado` y `/api/ptz` en 0,02–0,04 s |
| 2026-10-11 | Página real en Edge headless tras desplegar | Estado, posiciones y galería cargan; `node --check` OK |
| 2026-10-11 | Botón Apagar: diálogo en ancho de celular (390 px) | Se ve bien; `sudo -n -l systemctl poweroff` permitido. **No se probó apagar de verdad** |
| 2026-10-25 | Firmware `AutoStudio360.ino` con `arduino-cli` (esp32:esp32:esp32) | Compila (372 KB, 28 %); subido; `PING`/`INFO`/`STATUS` OK |
| 2026-10-25 | Luces por serial desde el PC | `TEST` OK; zonas separadas; frío/cálido por zona; rampas de tono 2700↔6500 K y brillo 0↔100 % |
| 2026-10-25 | Página con API simulada (Playwright + Edge, 1280 px y 390 px) | Menús, escenas, barras, Probar, giros y aviso "ESP32 desconectado"; 0 errores JS; `node --check` OK |
| 2026-10-25 | Página real en la Pi + ESP32 en `/dev/ttyUSB0` | `/api/esp32` conectado; escenas y barras mueven las torres; menú Base sin motor |
| 2026-10-25 | Luces tras volver a montar las cintas en los perfiles | Cálido puro, frío puro, cruzados en los dos sentidos, rampas: OK |
| 2026-10-25 | Arranque completo de la Pi con la Link 2 | Cámara en pan 0 / tilt 0 / zoom 100; `get_throttled=0x0` |
| 2026-11-08 | ffmpeg 7.1 en la Pi con archivos sintéticos: `-display_rotation` con `-c copy`, foto 4K con `transpose=1` | Marca de giro −90 en el MP4; foto 2160×3840 en 1,7 s |
| 2026-11-08 | Orientación vertical con la cámara real (API desde el PC) | Foto 4K 2160×3840 (3,6 s), 1080p 1080×1920, video 4 s 1080×1920, miniatura 270×480, copia Telegram 720×1280 en 10 s; giro 270 y formato "vertical" rechazados |
| 2026-11-08 | Página real en Edge (Playwright, 1280 px y 390 px) | Botones Horizontal/Vertical, vista 9:16 sin desbordar, formatos renombrados; 0 errores JS; `node --check` OK; video vertical se reproduce derecho |
| 2026-11-08 | Recorte 4:5 (descartado) | Foto 2160×2700, video 1080×1350 recortado sin recodificar (`h264_metadata` crop) y respetado por Edge |
| 2026-11-08 | Conexión a `AutoStudio360` desde Windows con perfil `netsh` | Conectado, 89 %, IP 10.42.0.238, página 200 |
| 2026-10-30 | TMC2208 + motor: medidas (multímetro) | Bobinas rojo–azul y verde–negro 0,29 Ω (por confirmar en escala 200 Ω), aisladas; VM 12 V, VIO 3,3 V, EN 0 V, Vref 1,12 V |
| 2026-10-30 | Base por serial desde el PC (plato pequeño, 1:1) | `ROT ±90`, `TURN 12`, `SPIN 30`/`STOP`, `GOTO 0`: siempre en la marca; con ~450 g `TURN 12` y 3 × `TURN 8`: en la marca, sin calentamiento |
| 2026-10-30 | Menú Base de la web con ESP32 en la Pi | Todos los botones OK; 19 `POST /api/base` con 200 |
| 2026-10-30 | `rodaje.py` simulado (cámara y ESP32 falsos) | Vuelta, Paradas, Vaivén, Quieta y Cancelar con la secuencia y tiempos esperados; 5 s rechazado en Vuelta y Paradas. Vaivén ajustado (último giro terminaba 0,1 s tarde) |
| 2026-10-30 | Página con API simulada (Playwright + Edge, 1200 y 390 px) | Modos, aviso de 5 s, Cancelar, bloqueo del menú Base, sin ESP32 → Quieta, escenas alineadas; 0 errores JS; `node --check` y `py_compile` OK |
| 2026-10-30 | Video con base en la cámara real | **Sin probar**: falta la base armada en la cabina |
